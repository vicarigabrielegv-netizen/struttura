import com.viltrumites.client.tail.TailMesh;
import com.viltrumites.client.tail.TailParams;
import com.viltrumites.client.tail.TailRope;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StreamTokenizer;

/**
 * Prova da riga di comando della fisica della coda (stesso codice del gioco: client/tail/TailRope e TailMesh).
 * Legge uno scenario di frame (scritto da tools/generate_assets.py) e scrive la geometria risultante, che lo
 * script usa per disegnare le anteprime di Thula.
 *
 *   javac -d /tmp/rope src/main/java/com/viltrumites/client/tail/*.java tools/RopeHarness.java
 *   java -cp /tmp/rope RopeHarness scenario.txt risultato.txt
 *
 * Formato di ogni frame: tempo tratto-testa-mano tratto-mano-fine assottigliamento sx sy sz terrenoY nPin [i x y z peso]...
 *   nScatole [12 matrice, 6 estremi, aderenza]... nOperazioni [codice parametri]...
 *   operazioni: 1 = linea (da ax ay az bx by bz inarcamento), 2 = spirale (da cx cz ritardo calo peso),
 *   3 = forma a riposo (ex ey ez yaw forza)
 */
public final class RopeHarness {
    public static void main(String[] args) throws IOException {
        StreamTokenizer in = new StreamTokenizer(new FileReader(args[0]));
        in.resetSyntax();
        in.wordChars(33, 255);
        in.whitespaceChars(0, 32);
        int frames = (int) num(in);
        TailRope rope = new TailRope();
        TailMesh mesh = new TailMesh();
        try (BufferedWriter out = new BufferedWriter(new FileWriter(args[1]))) {
            out.write(frames + "\n");
            for (int f = 0; f < frames; f++) {
                double time = num(in);
                double headPart = num(in);
                rope.setSplitLengths(TailParams.GRIP_INDEX, headPart, num(in));
                rope.thin = num(in);
                rope.setSide(num(in), num(in), num(in));
                final double ground = num(in);
                rope.setGround(Double.isNaN(ground) ? null : (x, y, z) -> y < ground + 1.5D ? ground : Double.NaN);
                rope.clearPins();
                int nPins = (int) num(in);
                for (int k = 0; k < nPins; k++) {
                    int i = (int) num(in);
                    rope.pin(i, num(in), num(in), num(in), num(in));
                }
                int nCols = (int) num(in);
                TailRope.Collider[] cols = new TailRope.Collider[nCols];
                for (int k = 0; k < nCols; k++) {
                    TailRope.Collider c = new TailRope.Collider();
                    double[] m = new double[12];
                    for (int j = 0; j < 12; j++) {
                        m[j] = num(in);
                    }
                    c.setTransform(m);
                    c.setBox(num(in), num(in), num(in), num(in), num(in), num(in));
                    c.adhere = num(in) > 0.5D;
                    cols[k] = c;
                }
                rope.setColliders(cols, nCols);
                int nOps = (int) num(in);
                for (int k = 0; k < nOps; k++) {
                    int code = (int) num(in);
                    if (code == 1) {
                        rope.layoutLine((int) num(in), num(in), num(in), num(in), num(in), num(in), num(in), num(in));
                    } else if (code == 3) {
                        rope.layoutRest(num(in), num(in), num(in), num(in), num(in));
                    } else {
                        rope.layoutSpin((int) num(in), num(in), num(in), num(in), num(in), num(in));
                    }
                }
                rope.advance(time);
                mesh.build(rope, 0.0D, 0.0D, 0.0D);
                StringBuilder sb = new StringBuilder();
                sb.append(mesh.quads);
                for (int j = 0; j < mesh.quads * 4 * TailMesh.STRIDE; j++) {
                    sb.append(' ').append(String.format(java.util.Locale.ROOT, "%.5f", mesh.data[j]));
                }
                sb.append('\n');
                out.write(sb.toString());
            }
        }
    }

    private static double num(StreamTokenizer in) throws IOException {
        in.nextToken();
        return Double.parseDouble(in.sval);
    }
}
