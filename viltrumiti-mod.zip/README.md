# Viltrumites (Minecraft 1.20.1 - Forge 47.x)

Mod sui Viltrumiti della serie *Invincible*. Questa versione contiene il **Viltrumita generico** i boss **Anissa**, **Conquest** e **Omni-Man** il mini-boss **Thula** e la struttura **Base dei Guardiani del Globo**.

## Cosa fa il Viltrumita
- **Spawn**: solo con l'uovo (`Uovo generatore di Viltrumita`, tab *Spawn Eggs* del creativo). 8 varianti casuali: 4 uomini e 4 donne, con la tuta bianca della tua skin.
- **Combo leggera** di 3 colpi (diretto, gancio, calcio finale con knockback), anche in volo.
- **Parata**: copre il corpo e riduce i danni; genera onda d'urto e respinge l'attaccante. Dopo una parata contrattacca.
- **Schivata**: laterale o indietro, con finestra di invulnerabilita' e scatto; poi contrattacca. Ha un tempo di recupero, quindi si puo' colpire.
- **Volo**: si alza se il giocatore e' in aria/vola (elytra, creativo) o e' lontano, lo insegue, combatte in aria e ogni tanto porta lo scontro in alto.
- **Carica in volo** (dash) contro bersagli lontani.
- **Se pari con lo scudo**: usa il colpo **rompi-scudo** (disabilita lo scudo per 10 s) oppure lo **schianto pesante** a due mani (onda d'urto ad area).
- **Parata del giocatore**: quando il tuo scudo para un suo colpo c'e' un'onda d'urto e il Viltrumita rincula; se alzi lo scudo "al volo" (parata perfetta) o pari lo schianto, **barcolla**.
- Animazioni fluide: ogni stato ha keyframe con easing e c'e' una dissolvenza di 5 tick tra una posa e l'altra.

## Anissa (boss)
- **Evocazione**: solo con il comando `/summon viltrumites:anissa` (nessun uovo). Ha la barra del boss e non scompare mai da sola.
- **Vita**: almeno 200 punti (100 cuori) e **sempre 10 cuori in piu'** del giocatore piu' robusto nei dintorni, qualunque sia la sua vita massima; la vita massima di Anissa non cala mai. Costanti: `AnissaEntity.BASE_MAX_HEALTH` e `AnissaEntity.HEARTS_OVER_PLAYER`.
- **Stile**: combo di 4 colpi veloci (jab, diretto, gancio, calcio finale), schiva e para piu' spesso e contrattacca quasi sempre, rompe lo scudo.
- **Presa**: scatta e afferra il bersaglio (aggira lo scudo; se manca resta scoperta). Tenuto in mano, il bersaglio non puo' muoversi e poi:
  - viene **lanciato** lontano (danno extra se si schianta contro un muro o il suolo), oppure
  - subisce una **combo a catena** di 2-4 colpi (pugni, ginocchiata) chiusa da **montante**, **schianto a terra** o lancio.
  La presa si spezza se il bersaglio la colpisce con abbastanza forza (6% della vita massima in colpi).
- **Volo**: molto piu' veloce, intercetta la traiettoria del bersaglio (anche con elytra) e gli resta alle spalle.
- **Furia** sotto meta' vita: piu' prese, meno pause, ancora piu' veloce.
- Codice: `AnissaEntity` (stato, vita, presa), `AnissaCombatGoal` (IA), `AnissaModel`/`AnissaRenderer` (modello con strati della skin e petto in rilievo). La skin originale e' in `tools/anissa_skin_original.png` (braccia slim): lo script la converte in `textures/entity/anissa.png` con braccia da 4 pixel come il modello di riferimento.

## Conquest (boss)
- **Evocazione**: solo con `/summon viltrumites:conquest` (nessun uovo). Barra del boss viola (rossa in fase 2), non scompare mai da sola.
- **Aspetto**: modello con i parametri dell'editor (`conquest_modello_nuova_skin.png`): testa 10x10x10, busto 13,6x15,6x4,6, braccia 6x16,2x6, gambe 7,8x16,2x6 px; alto 41,8 px = **2,45 blocchi** con la scala 0,9375 del renderer (hitbox 0,9 x 2,45). Skin in `tools/conquest_skin.png` (copiata in `textures/entity/conquest.png`). Gli strati esterni sono gonfiati di 0,6 px (testa 0,9; manica destra 1,1).
- **Resistenza**: 320 punti di vita minimi e **sempre 20 cuori in piu'** del giocatore piu' robusto vicino (`ConquestEntity.CONQUEST_BASE_HEALTH`, `CONQUEST_HEARTS_OVER_PLAYER`), armatura 20 / tenacia 12, nessun contraccolpo, **-15% ai danni subiti** (-25% in fase 2), guardia molto difficile da rompere, presa difficile da spezzare (10% della vita massima).
- **Stile**: combo di 4 colpi velocissimi, vola e carica piu' veloce di Anissa, schiva (52%) e para piu' spesso e contrattacca quasi sempre, rompe gli scudi, prende il bersaglio piu' spesso.
- **Combo firma** (parte da una presa, aggira lo scudo): **afferra** il giocatore, lo **blocca a terra**, lo colpisce con un **pugno devastante** (onda d'urto e crepa nel terreno, danni anche a chi e' intorno; 2 pugni in fase 2) e infine con un **montante che lo lancia in aria** (`ConquestEntity.LAUNCH_SPEED`), poi lo insegue in volo. Se sotto non c'e' terreno ripiega sul lancio normale di Anissa. Tutta la presa di Anissa (lancio, catena di colpi, montante, schianto) resta disponibile.
- **Fase 2** a meta' vita: il combattimento si ferma (Conquest e' invulnerabile e i giocatori vicini restano immobili), **cinematica** di 5,5 secondi con camera che trema, bande nere da film, aura di scintille, fulmine scenografico ed esplosione finale. Conquest parla in chat (3 battute, in `lang/*.json`, chiavi `viltrumites.conquest.phase2.line1-3`): e' contento dello scontro e vuole di piu'. Poi si **potenzia** (+30% danni, +15% velocita' e volo, +6 armatura, piu' prese e meno pause) e riprende lo scontro. Non si puo' saltare la fase: anche un colpo enorme lo lascia a meta' vita.
- **Alla sconfitta**: achievement **"I'm so alone"** (sfida, nascosto nella scheda Avventura finche' non si ottiene, con annuncio in chat e 1000 punti esperienza) e 2000 punti esperienza dal boss (`ConquestEntity.XP_REWARD`). File: `data/viltrumites/advancements/im_so_alone.json`, testi nei `lang`.
- Codice: `ConquestEntity` (fasi, cinematica, resistenza), `ConquestCombatGoal` (IA e combo firma), `ConquestModel`/`ConquestRenderer`, `client/ConquestCinematic` (tremolio e bande nere); riusa `AnissaEntity`/`AnissaCombatGoal` (presa, barra, vita).

## Omni-Man (boss)
- **Evocazione**: solo con `/summon viltrumites:omniman` (nessun uovo). Barra del boss rossa.
- **Aspetto**: modello con i parametri dell'editor (`omniman_modello_con_skin.png`): tutte le parti x 1,05 (testa 8,4^3, busto 8,4x12,6x4,2, braccia e gambe 4,2x12,6x4,2), alto 33,6 px = **1,97 blocchi** con la scala 0,9375 (hitbox 0,7 x 1,97). Skin in `tools/omniman_skin.png`; la texture finale (`textures/entity/omniman.png`, 64x128) la compone lo script: skin in alto, **mantello** sotto (rosso #b3141c, 14,7 x 24,15 px, generato dallo script perche' non era nella skin).
- **Mantello**: catena di 3 segmenti (`cape0-2` in `OmniManModel`) appesa 1,05 px sotto la spalla e 2,52 px dietro la schiena. A riposo cade dritto, si apre all'indietro con la velocita', si solleva in picchiata e ondeggia: e' un'approssimazione della stoffa simulata dell'editor (che non si puo' replicare in gioco). Anche il colore/le pieghe sono in `cape_art()` dello script.
- **Resistenza e ritmo**: 260 punti di vita minimi e **15 cuori in piu'** del giocatore piu' robusto vicino, armatura 16 / tenacia 10, -12% ai danni subiti. Combo di 4 colpi e volo piu' lenti di Anissa e Conquest (`speedMul` 1,35), ma schiva (40%) e para (30%) e contrattacca spesso. Niente "furia" a meta' vita.
- **Contrattacco** (la sua specialita'): quando il giocatore lo colpisce in **corpo a corpo** (non con i proiettili), con una certa probabilita' Omni-Man **alza la mano e ferma il colpo** (nessun danno, chi ha attaccato resta bloccato un istante), poi lo **colpisce e lo respinge lontano**. All'inizio e' raro e diventa piu' frequente man mano che perde vita: 16% con una pausa minima di 13 s sopra il 75% di vita, 24% / 10 s fino al 50%, 32% / 7,5 s fino al 25%, 40% / 5,5 s dopo. Parametri in `OmniManEntity.catchChance()` e `catchCooldownTicks()`.
- **Presa firma**: afferra il giocatore, lo **sbatte a terra** (danno, onda d'urto e crepa), lo **riempie di pugni** (8 colpi alternati) e lo **lascia andare con una spinta**, poi riprende lo scontro. Se sotto non c'e' terreno ripiega sul lancio di Anissa. Il 35% delle volte usa invece la presa di Anissa (lancio, catena di colpi, montante, schianto). Tutte le prese aggirano lo scudo.
- **Alla sconfitta**: achievement **"500 anni..."** (in inglese **"500 years..."**; sfida, nascosto nella scheda Avventura finche' non si ottiene, con annuncio in chat e 500 punti esperienza) e 1500 punti esperienza dal boss (`OmniManEntity.XP_REWARD`). File: `data/viltrumites/advancements/five_hundred_years.json`, testi nei `lang`.
- Codice: `OmniManEntity` (contrattacco, resistenza), `OmniManCombatGoal` (IA e presa firma), `GroundPin` (aiuti per inchiodare a terra), `OmniManModel`/`OmniManRenderer`; riusa `AnissaEntity`/`AnissaCombatGoal` (presa, barra, vita).

## Thula (mini-boss)
- **Evocazione**: solo con `/summon viltrumites:thula` (nessun uovo). Barra del boss blu. Alta come il giocatore (1,88 blocchi, scala 0,9375, hitbox 0,6 x 1,88).
- **Aspetto**: modello con i parametri dell'editor (`thula_modello_parametri.png`): testa 8^3, busto 8x12x4, gambe 4x12x4 e **braccia slim 3x12x4** (spalla a 22,8 px da terra), strato esterno 0,25 (capelli 0,55). Skin in `tools/thula_skin.png`; la texture finale (`textures/entity/thula.png`, 64x128) la compone lo script: skin in alto, sotto **treccia** (16x16, intrecci diagonali coi grigi dei suoi capelli, sfumata verso la punta), **legaccio** scuro (capelli x 0,55) e **lama** (#c9d1d9).
- **La coda e' una corda con fisica vera** (`client/tail/TailRope`, la parte che puo' girare anche fuori da Minecraft): 22 punti (20 della treccia + 2 della lama), lunghezza 27 px + legaccio 1,8 + lama 7 x 2,9 x 0,5; i primi 2 punti sono fissi alla testa (attacco al 75% dell'altezza, dietro, dentro i capelli), gli altri sono liberi. Vincoli di distanza e di piegatura (rigidita' 0,5), gravita' (peso 0,8, la punta piu' pesante), vento 1, aderenza alla schiena 0,02, **collisione con busto, gambe, testa e terreno**. Sezione quadrata che va da raggio 1,55 a 0,8 (`TailMesh`). La fisica e' simulata sul client ad ogni frame (`ThulaRenderer`); il server decide solo cosa fa la coda (stati sincronizzati) e dove colpisce.
- **Fase 1** (da 100% a 50% della vita): combatte **a mani nude**, agile e veloce (combo da 4 colpi, molte schivate e parate, volo rapido). Niente prese: la sua presa e' la coda.
- **Fase 2** (a meta' vita): per ~1,4 s e' intoccabile mentre **prende la coda in mano** (la vita non scende mai sotto il 50% prima: non si salta la fase). Da qui ha una **posizione di attacco** con la coda stretta nella mano destra, e tre armi:
  - **Rotazione** (`ST_SPIN`): carica, poi **gira su se stessa** per 1,5 giri con la coda tesa: un **cerchio di raggio 4,3 blocchi** (la punta della lama arriva li') che spazza quasi tutta la zona intorno, alto da 0,4 sotto a 2,6 sopra i suoi piedi (saltare non basta). Chi viene preso subisce 1,15x il danno base e viene **respinto lontano** (1,7 blocchi; con lo scudo 0,9). Se la parti con uno scudo al momento giusto (parata perfetta) la ferma.
  - **Lancio** (`ST_WHIP`): carica, poi la coda **parte verso il giocatore** (direzione bloccata al lancio, 1,45 blocchi/tick, fino a **8 blocchi**, si ferma contro i blocchi). **Se lo manca**, arriva alla lunghezza massima e **torna in mano**. **Se lo prende**, lo **tira a se'** e lo **colpisce** (2,2x il danno base, spinta forte, rompe lo scudo). Se il giocatore la colpisce forte mentre lo tira, lo molla.
  - **Colpi normali** a mani nude con la coda che frusta a ogni movimento.
  - Vola, para e schiva come le altre: non schiva o para mentre ruota, lancia o prende la coda.
- **Vita**: 160 base e **sempre 8 cuori piu' del giocatore piu' robusto vicino** (mini-boss: meno di Anissa); 900 punti esperienza (`ThulaEntity.XP_REWARD`).
- Codice: `ThulaEntity` (stato, fasi, parametri), `ThulaCombatGoal` (IA: rotazione e lancio), `ThulaModel`/`ThulaRenderer` (modello e disegno della coda), `client/tail/TailParams` (tutte le costanti), `TailRope` (fisica), `TailMesh` (geometria); riusa `AnissaEntity` (barra, vita, presa) e le animazioni di Anissa per i colpi. Pose e animazioni nuove (`T_*`) in `tools/generate_assets.py`.

## Base dei Guardiani del Globo (struttura)
- **Cos'e'**: un grande tamburo circolare (diametro 73, alto 49) con una sala a cupola, piattaforma blu e un corridoio d'ingresso lungo il lato +X. Il disegno e' il template `src/main/resources/data/viltrumites/structures/guardians_hq.nbt` (il tuo `guardians_hq.nbt`: l'unica modifica e' il campo `DataVersion`, portato a quello di 1.20.1; i blocchi sono identici). Usa solo blocchi vanilla.
- **Unica**: una sola per mondo (una per dimensione compatibile). `GuardiansHqSite` sceglie in modo deterministico, dal seed e dai biomi, **una sola casella** della griglia `random_spread` del file `worldgen/structure_set/guardians_hq.json` (spaziatura 64 chunk): tutte le altre vengono scartate. Non dipende da file salvati, quindi non cambia ricaricando il mondo.
- **Lontana dallo spawn**: da **2500 blocchi** dall'origine in su; si cerca fino a 6000 e solo se non c'e' niente di adatto si allarga fino a 10000 (`GuardiansHq.MIN_DISTANCE`, `NEAR_MAX_DISTANCE`, `FAR_MAX_DISTANCE`). Con `/locate` non si trova dallo spawn (raggio di 100 chunk): serve esplorare, oppure il comando per operatori `/viltrumites hq`, che stampa le coordinate del centro della base (e' una scorciatoia da creativa/test).
- **Senza sovrapposizioni**: per ogni posto possibile si guardano le altre strutture (vanilla e di altre mod) che potrebbero nascere in quel bioma e si scarta il posto se un loro punto di partenza e' entro **8 chunk** (`GuardiansHq.CLEAR_RANGE`): niente miniere, villaggi, fortezze ecc. a ridosso, quindi niente da cancellare. Se con 8 chunk non c'e' nessun posto si prova con 4, e solo in ultimo senza controllo. Funziona con le strutture di qualunque mod che usa i normali structure_set.
- **Dove**: prima una **montagna** (tag `guardians_hq_mountains`), poi un qualunque altro bioma valido. Mai in acqua. I biomi sono tag (`data/viltrumites/tags/worldgen/biome/has_structure/`):
  - `guardians_hq_mountains`: montagne (vanilla: `#minecraft:is_mountain`, `#minecraft:is_hill`, picchi, pendii, boschetto, prato, ciliegi, altopiani ventosi; mod: `#forge:is_mountain`, `#forge:is_peak`, `#forge:is_slope`, `#forge:is_hill`, `#forge:is_plateau`, `#c:is_mountain`, `#c:mountain`, tutti opzionali). I biomi di altre mod si aggiungono qui, o con i tag standard.
  - `guardians_hq`: i biomi dove la base e' ammessa (montagne + foreste, taiga, giungla, savana, badlands, pianure, deserto, palude e `#forge:is_overworld` se esiste). **Per avere la base solo in montagna** togli dal file tutto tranne la prima riga (`#viltrumites:has_structure/guardians_hq_mountains`): in alcuni mondi allora non comparira' affatto.
- **Nascosta**: `GuardiansHqStructure` affonda la base nella roccia in modo che il tetto stia 8 blocchi sotto il punto piu' basso della superficie sopra la sua impronta (`GuardiansHq.COVER`). Funziona con qualunque generatore (usa l'altezza del terreno del generatore in uso, la quota minima e massima della dimensione).
- **Ingresso dalla montagna**: prova le 4 rotazioni e sceglie il lato dove la montagna scende (rampa piu' corta, evitando uscite in acqua). Da li' `GuardiansTunnelPiece` scava una **rampa a gradini** (1 blocco in alto ogni blocco, larga 7, alta 5) con rivestimento in mattoni di ardesia profonda e lanterne marine, fino a sbucare sulla superficie. Sotto la superficie pareti, soffitto e pavimento sono sempre completi (anche dove la rampa taglia una grotta), cosi' non restano buchi. Lunghezza massima 88 gradini (`GuardiansHq.MAX_STEPS`): oltre i 128 blocchi dal punto di partenza il gioco non genera piu' i pezzi di una struttura. Se nessun lato arriva in superficie, la base viene alzata a passi di 8 blocchi (fino a 24).
- **Niente mostri**: dentro la base e la rampa non nascono mostri ostili (`spawn_overrides` di `monster` vuoto in `worldgen/structure/guardians_hq.json`, vale anche per i mostri aggiunti da altre mod alla categoria *monster*). Restano gli animali e il resto. Mostri nati altrove possono comunque entrare dall'ingresso.
- **Trovarla**: `/viltrumites hq` (operatori) oppure esplorare; `/locate structure viltrumites:guardians_hq` funziona solo entro 100 chunk. Il template non contiene ne' bauli ne' mob.
- Se cambi `spacing`, `separation` o `salt` nel JSON, cambia gli stessi valori in `GuardiansHq` (`SPACING`, `SEPARATION`, `SALT`).
- Anteprime: `preview/guardians_hq_pianta.png` (viste dall'alto), `guardians_hq_sezione.png` (sezione laterale) e `guardians_hq_ingresso_simulato.png` (simulazione della rampa su una montagna finta).

## Compilare
1. Carica tutto il contenuto della cartella su GitHub (il workflow `.github/workflows/build.yml` compila con Java 17 e Gradle 8.1.1).
2. Scarica il jar dall'artifact `viltrumites-mod` in *Actions*.
3. Mettilo nella cartella `mods` di Minecraft 1.20.1 con Forge 47.x.

In locale: `gradle build` (Java 17), il jar finisce in `build/libs/`.

## Modificare pose e texture
Tutto passa da `tools/generate_assets.py` (richiede Pillow e numpy):

    python3 tools/generate_assets.py            # texture + Poses.java + anteprime
    python3 tools/generate_assets.py conquest   # solo texture e anteprime di Conquest
    python3 tools/generate_assets.py omniman    # solo texture (skin + mantello) e anteprime di Omni-Man
    python3 tools/generate_assets.py thula      # solo texture e anteprime di Thula (serve un JDK: simula la coda con il codice del gioco)

- `tools/skin_base.png`: la tuta di partenza. Visi, capelli e mani vengono aggiunti dallo script (lista `VARIANTS`).
- Le pose (`STANCE`, `L0_H`, ...) e le animazioni (`ANIMS`) sono in radianti; `Poses.java` e' generato.
- Bilanciamento (vita, danno, velocita'): `ViltrumiteEntity.createAttributes()`.
- Tempi e probabilita' dell'IA: `ViltrumiteCombatGoal` (generico), `AnissaCombatGoal`, `ConquestCombatGoal`, `OmniManCombatGoal` e `ThulaCombatGoal` (boss). Fisica e dimensioni della coda di Thula: `client/tail/TailParams` (gravita', rigidita', vento, raggio della rotazione, portata del lancio...). Per provare la fisica da riga di comando: `javac -d /tmp/rope src/main/java/com/viltrumites/client/tail/*.java tools/RopeHarness.java`.
- Bilanciamento di Conquest: attributi in `ConquestEntity.createConquestAttributes()`, danni dei colpi firma in `ConquestCombatGoal` (moltiplicatori di `base()`), potenziamento in `ConquestEntity.applyPhase2()`.

## Anteprime
Nella cartella `preview/`: pose, varianti (fronte/retro) e volti dei Viltrumiti, piu' `anissa_modello.png`, `anissa_pose_combattimento.png`, `anissa_pose_attacco.png` le tre di Conquest (`conquest_modello.png`, `conquest_pose_combattimento.png`, `conquest_pose_attacco.png`) le tre di Omni-Man (`omniman_modello.png`, `omniman_pose_combattimento.png`, `omniman_pose_attacco.png`) le tre di Thula (`thula_modello.png`, `thula_pose_combattimento.png`, `thula_pose_attacco.png`, con la coda simulata dal codice vero del gioco) e le tre della Base dei Guardiani (`guardians_hq_pianta.png`, `guardians_hq_sezione.png`, `guardians_hq_ingresso_simulato.png`).
