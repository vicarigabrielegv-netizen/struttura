package com.viltrumites.entity;

import com.viltrumites.entity.ai.ConquestCombatGoal;
import com.viltrumites.fx.CombatFx;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;

/**
 * Conquest, il Viltrumita boss (compare solo con {@code /summon viltrumites:conquest}).
 *
 * Rispetto ad Anissa (di cui riusa presa, barra del boss e adattamento della vita ai cuori del giocatore):
 *  - molto piu' resistente: piu' vita, armatura, nessun contraccolpo e danni subiti ridotti (vedi {@link #hurt});
 *  - molto piu' veloce e aggressivo, con parate e schivate piu' frequenti;
 *  - combo firma (vedi {@link ConquestCombatGoal}): afferra il bersaglio, lo BLOCCA A TERRA, lo colpisce con un
 *    pugno devastante e poi lo LANCIA IN ARIA (stati ST_HOLD sub 7, 8 e 9);
 *  - a meta' vita parte la FASE 2: cinematica di potenziamento (stato ST_POWERUP) in cui il combattimento si
 *    ferma, Conquest parla in chat, poi si potenzia (danni, velocita', armatura) e riprende lo scontro.
 */
public class ConquestEntity extends AnissaEntity {
    /** Vita minima (punti, 2 = 1 cuore). */
    public static final double CONQUEST_BASE_HEALTH = 320.0D;
    /** Cuori che Conquest ha SEMPRE in piu' del giocatore piu' robusto vicino. */
    public static final int CONQUEST_HEARTS_OVER_PLAYER = 20;
    /** Frazione di vita sotto cui scatta la fase 2. */
    public static final float PHASE2_HEALTH_FRACTION = 0.5F;
    /** Durata della cinematica di potenziamento (tick). */
    public static final int POWERUP_TICKS = 110;
    /** Velocita' verticale con cui il montante lancia il bersaglio in aria. */
    public static final double LAUNCH_SPEED = 1.55D;
    /** Esperienza lasciata alla morte. */
    public static final int XP_REWARD = 2000;

    /** Sotto-stati di ST_HOLD propri di Conquest. */
    public static final int SUB_PIN = 7;
    public static final int SUB_PUNCH = 8;
    public static final int SUB_LAUNCH = 9;

    private static final double FREEZE_RANGE = 48.0D;
    private static final double TALK_RANGE = 96.0D;

    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(ConquestEntity.class, EntityDataSerializers.INT);

    /** Tick rimasti alla cinematica (0 = nessuna cinematica in corso). */
    private int powerupTicks;

    public ConquestEntity(EntityType<? extends ConquestEntity> type, Level level) {
        super(type, level);
        this.xpReward = XP_REWARD;
    }

    public static AttributeSupplier.Builder createConquestAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, CONQUEST_BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.48D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.ARMOR, 20.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 12.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.FLYING_SPEED, 1.3D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new ConquestCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // da' la caccia ai giocatori anche senza linea di vista
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_PHASE, 1);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Phase", getPhase());
        tag.putInt("PowerUp", powerupTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Phase")) {
            this.entityData.set(DATA_PHASE, Math.max(1, Math.min(2, tag.getInt("Phase"))));
        }
        this.powerupTicks = Math.max(0, tag.getInt("PowerUp"));
        if (getPhase() >= 2) {
            this.bossEvent.setColor(BossEvent.BossBarColor.RED);
        }
    }

    // ------------------------------------------------------------------ ganci di Anissa
    @Override
    protected BossEvent.BossBarColor bossBarColor() {
        return BossEvent.BossBarColor.PURPLE;
    }

    @Override
    protected double baseMaxHealth() {
        return CONQUEST_BASE_HEALTH;
    }

    @Override
    protected int heartsOverPlayer() {
        return CONQUEST_HEARTS_OVER_PLAYER;
    }

    @Override
    protected float holdBreakFraction() {
        return 0.10F;      // la sua presa e' molto piu' difficile da spezzare
    }

    // ------------------------------------------------------------------ fase
    public int getPhase() {
        return this.entityData.get(DATA_PHASE);
    }

    /** In fase 2 Conquest e' "infuriato": pause piu' brevi e piu' prese (vedi i goal). */
    @Override
    public boolean isEnraged() {
        return getPhase() >= 2;
    }

    public boolean isPoweringUp() {
        return getCombatState() == ST_POWERUP;
    }

    // ------------------------------------------------------------------ tempi e parametri di combattimento
    @Override
    public int stateDuration(int state, int sub) {
        boolean p2 = getPhase() >= 2;
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? (p2 ? 9 : 11) : (p2 ? 7 : 8);      // combo velocissima
            case ST_POWERUP:
                return POWERUP_TICKS;
            case ST_HOLD:
                if (sub == SUB_PIN) {
                    return 16;
                } else if (sub == SUB_PUNCH) {
                    return p2 ? 18 : 22;
                } else if (sub == SUB_LAUNCH) {
                    return 20;
                }
                return super.stateDuration(state, sub);
            default:
                return super.stateDuration(state, sub);
        }
    }

    @Override
    public int stateHitTick(int state, int sub) {
        boolean p2 = getPhase() >= 2;
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? 5 : 3;
            case ST_HOLD:
                if (sub == SUB_PIN) {
                    return 9;
                } else if (sub == SUB_PUNCH) {
                    return p2 ? 9 : 11;
                } else if (sub == SUB_LAUNCH) {
                    return 8;
                }
                return super.stateHitTick(state, sub);
            default:
                return super.stateHitTick(state, sub);
        }
    }

    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.8F : (isFlying() ? 0.62F : 0.52F);
    }

    @Override
    protected float guardChance() {
        return 0.34F;
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 26;
    }

    @Override
    protected float dodgeCounterChance() {
        return 0.9F;
    }

    @Override
    protected float guardCounterChance() {
        return 0.85F;
    }

    @Override
    protected int guardBreakHits() {
        return 9;          // la sua guardia e' molto piu' difficile da rompere
    }

    @Override
    protected float guardBreakDamage() {
        return 40.0F;
    }

    @Override
    protected boolean isCommitted(int state) {
        return super.isCommitted(state) || state == ST_POWERUP;
    }

    // ------------------------------------------------------------------ danni subiti
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (powerupTicks > 0) {
                return false;                          // invulnerabile durante la cinematica
            }
            amount *= getPhase() >= 2 ? 0.75F : 0.85F;  // resistenza: subisce meno danni, ancora meno in fase 2
        }
        return super.hurt(source, amount);
    }

    /**
     * Dopo l'applicazione del danno: se la vita e' scesa a meta' (o oltre) in fase 1, la vita viene riportata
     * esattamente a meta' (non puo' saltare la fase 2 nemmeno con un colpo enorme) e parte la cinematica.
     */
    @Override
    protected void actuallyHurt(DamageSource source, float amount) {
        super.actuallyHurt(source, amount);
        if (!this.level().isClientSide && getPhase() < 2 && powerupTicks <= 0
                && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            float threshold = this.getMaxHealth() * PHASE2_HEALTH_FRACTION;
            if (this.getHealth() <= threshold) {
                this.setHealth(threshold);
                startPowerUp();
            }
        }
    }

    // ------------------------------------------------------------------ presa: bloccare a terra
    /** Trascina la vittima afferrata verso un punto (tipicamente il suolo davanti a Conquest). Solo server. */
    public void pinVictim(Vec3 point) {
        LivingEntity v = getGrabbed();
        if (v == null) {
            return;
        }
        v.setDeltaMovement(point.subtract(v.position()).scale(0.75D));
        v.hurtMarked = true;
        v.fallDistance = 0.0F;
        if (v instanceof Player) {
            v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 9, false, false, false));
        }
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            clientAura();
        } else if (powerupTicks > 0) {
            tickPowerUp();
        }
    }

    private void clientAura() {
        boolean up = isPoweringUp();
        if (!up && getPhase() < 2) {
            return;
        }
        int n = up ? 3 : 1;
        for (int i = 0; i < n; i++) {
            double a = this.random.nextDouble() * Math.PI * 2.0D;
            double r = 0.5D + this.random.nextDouble() * 0.6D;
            this.level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                    this.getX() + Math.cos(a) * r, this.getY() + this.random.nextDouble() * this.getBbHeight(),
                    this.getZ() + Math.sin(a) * r, 0.0D, 0.04D, 0.0D);
        }
        if (up && this.tickCount % 2 == 0) {
            this.level().addParticle(ParticleTypes.SOUL_FIRE_FLAME,
                    this.getRandomX(0.8D), this.getY() + 0.1D, this.getRandomZ(0.8D), 0.0D, 0.12D, 0.0D);
        }
    }

    // ------------------------------------------------------------------ cinematica di potenziamento
    private void startPowerUp() {
        this.releaseGrab();
        this.powerupTicks = POWERUP_TICKS;
        this.setCombatState(ST_POWERUP, 0);
        this.getNavigation().stop();
        if (this.level() instanceof ServerLevel server) {
            CombatFx.powerUpStart(server, this.position());
        }
    }

    private void tickPowerUp() {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        int t = POWERUP_TICKS - powerupTicks;
        if (this.getCombatState() != ST_POWERUP) {
            this.setCombatState(ST_POWERUP, 0);         // un altro goal l'ha interrotto: la cinematica continua
        }

        // fermo sul posto (se in volo scende piano fino a terra)
        this.getNavigation().stop();
        Vec3 dm = this.getDeltaMovement();
        if (isFlying()) {
            if (groundDistance(this) > 0.5D) {
                this.setDeltaMovement(0.0D, -0.15D, 0.0D);
            } else {
                this.setFlying(false);
                this.setDeltaMovement(Vec3.ZERO);
            }
        } else {
            this.setDeltaMovement(0.0D, Math.min(dm.y, 0.0D), 0.0D);
        }

        // il combattimento si ferma: i giocatori vicini restano bloccati a guardare
        for (ServerPlayer p : server.players()) {
            if (!p.isSpectator() && p.distanceToSqr(this) < FREEZE_RANGE * FREEZE_RANGE) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5, 9, false, false, false));
            }
        }

        if (t % 2 == 0) {
            CombatFx.powerUpAura(server, this.position(), t / (float) POWERUP_TICKS);
        }
        if (t == 8) {
            say(server, 1);
        } else if (t == 44) {
            say(server, 2);
        } else if (t == 80) {
            say(server, 3);
        }
        if (t == POWERUP_TICKS - 14) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server);
            if (bolt != null) {
                bolt.moveTo(this.getX(), this.getY(), this.getZ());
                bolt.setVisualOnly(true);              // solo scenografia: nessun danno e nessun incendio
                server.addFreshEntity(bolt);
            }
        }

        powerupTicks--;
        if (powerupTicks <= 0) {
            powerupTicks = 0;
            finishPowerUp(server);
        }
    }

    private void finishPowerUp(ServerLevel server) {
        applyPhase2();
        this.setCombatState(ST_NEUTRAL, 0);
        CombatFx.powerUpBurst(server, this.position().add(0.0D, 0.2D, 0.0D));
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(12.0D),
                x -> x != this && !(x instanceof ViltrumiteEntity))) {
            Vec3 away = e.position().subtract(this.position()).multiply(1.0D, 0.0D, 1.0D);
            away = away.lengthSqr() > 1.0E-4D ? away.normalize() : this.flatLook();
            push(e, away.scale(1.6D).add(0.0D, 0.5D, 0.0D));    // onda d'urto: respinge senza fare danni
        }
    }

    /** Il potenziamento: piu' danni, piu' velocita', piu' armatura. */
    private void applyPhase2() {
        this.entityData.set(DATA_PHASE, 2);
        scaleAttribute(Attributes.ATTACK_DAMAGE, 1.3D);
        scaleAttribute(Attributes.MOVEMENT_SPEED, 1.15D);
        scaleAttribute(Attributes.FLYING_SPEED, 1.15D);
        AttributeInstance armor = this.getAttribute(Attributes.ARMOR);
        if (armor != null) {
            armor.setBaseValue(armor.getBaseValue() + 6.0D);
        }
        this.bossEvent.setColor(BossEvent.BossBarColor.RED);
    }

    private void scaleAttribute(Attribute attribute, double mul) {
        AttributeInstance a = this.getAttribute(attribute);
        if (a != null) {
            a.setBaseValue(a.getBaseValue() * mul);
        }
    }

    /** Battuta di Conquest in chat ("<Conquest> ..."), tradotta dal file di lingua di chi la legge. */
    private void say(ServerLevel server, int line) {
        Component msg = Component.translatable("chat.type.text", this.getDisplayName(),
                Component.translatable("viltrumites.conquest.phase2.line" + line));
        for (ServerPlayer p : server.players()) {
            if (p.distanceToSqr(this) < TALK_RANGE * TALK_RANGE) {
                p.sendSystemMessage(msg);
            }
        }
    }
}
