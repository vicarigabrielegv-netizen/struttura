package com.viltrumites.entity;

import com.viltrumites.entity.ai.AnissaCombatGoal;
import com.viltrumites.fx.CombatFx;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Anissa, la Viltrumita boss. Compare solo con {@code /summon viltrumites:anissa}.
 *
 * - Vita: almeno {@link #BASE_MAX_HEALTH}, e sempre {@link #HEARTS_OVER_PLAYER} cuori in piu' del giocatore
 *   piu' "robusto" nei dintorni, quanti che siano i suoi cuori (non scende mai).
 * - Combattimento: combo da 4 colpi, schivate/parate piu' frequenti, volo molto piu' veloce, presa con lancio
 *   o con combo a catena (stati ST_GRAB / ST_HOLD, vedi {@link AnissaCombatGoal}).
 * - Sotto meta' vita entra in furia: piu' presa, meno pause.
 */
public class AnissaEntity extends ViltrumiteEntity {
    /** Vita minima (punti, 2 = 1 cuore). */
    public static final double BASE_MAX_HEALTH = 200.0D;
    /** Cuori che Anissa ha SEMPRE in piu' del giocatore piu' robusto vicino. */
    public static final int HEARTS_OVER_PLAYER = 10;
    /** Velocita' (blocchi/tick) con cui scaglia chi ha afferrato. */
    public static final double THROW_SPEED = 2.5D;

    protected final ServerBossEvent bossEvent = new ServerBossEvent(this.getDisplayName(),
            this.bossBarColor(), BossEvent.BossBarOverlay.NOTCHED_10);

    @Nullable
    private LivingEntity grabbed;
    private float holdDamage;
    private final List<Thrown> thrown = new ArrayList<>();

    public AnissaEntity(EntityType<? extends AnissaEntity> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAnissaAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, BASE_MAX_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.42D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.ARMOR, 14.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 8.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.FOLLOW_RANGE, 72.0D)
                .add(Attributes.FLYING_SPEED, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AnissaCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // il boss da' la caccia ai giocatori anche senza linea di vista
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ------------------------------------------------------------------ barra del boss e vita
    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        this.bossEvent.setName(this.getDisplayName());
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.tickCount % 20 == 0) {
            updateHealthScaling();
        }
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
    }

    /** Porta la vita massima ad almeno (cuori del giocatore piu' forte vicino + HEARTS_OVER_PLAYER). Non cala mai. */
    private void updateHealthScaling() {
        double strongest = 0.0D;
        for (Player p : this.level().players()) {
            if (!p.isSpectator() && p.distanceToSqr(this) < 96.0D * 96.0D) {
                strongest = Math.max(strongest, p.getMaxHealth());
            }
        }
        double wanted = Math.max(baseMaxHealth(), strongest + heartsOverPlayer() * 2.0D);
        AttributeInstance max = this.getAttribute(Attributes.MAX_HEALTH);
        if (max != null && wanted > max.getBaseValue() + 0.01D) {
            float ratio = this.getHealth() / this.getMaxHealth();
            max.setBaseValue(wanted);
            this.setHealth(this.getMaxHealth() * ratio);
        }
    }

    public boolean isEnraged() {
        return this.getHealth() < this.getMaxHealth() * 0.5F;
    }

    // ---- ganci per i boss derivati (Conquest): valori di Anissa di default
    protected BossEvent.BossBarColor bossBarColor() {
        return BossEvent.BossBarColor.WHITE;
    }

    protected double baseMaxHealth() {
        return BASE_MAX_HEALTH;
    }

    protected int heartsOverPlayer() {
        return HEARTS_OVER_PLAYER;
    }

    /** Frazione della vita massima che il bersaglio deve infliggere mentre e' afferrato per spezzare la presa. */
    protected float holdBreakFraction() {
        return 0.06F;
    }

    // ------------------------------------------------------------------ tempi e parametri di combattimento
    @Override
    public int stateDuration(int state, int sub) {
        if (state == ST_LIGHT) {
            return sub >= 3 ? 13 : 10;      // combo piu' veloce di quella dei Viltrumiti normali
        }
        return super.stateDuration(state, sub);
    }

    @Override
    public int stateHitTick(int state, int sub) {
        if (state == ST_LIGHT) {
            return sub >= 3 ? 6 : 4;
        }
        return super.stateHitTick(state, sub);
    }

    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.75F : (isFlying() ? 0.58F : 0.46F);
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 32;
    }

    @Override
    protected float dodgeCounterChance() {
        return 0.8F;
    }

    @Override
    protected float guardCounterChance() {
        return 0.75F;
    }

    @Override
    protected int guardBreakHits() {
        return 6;
    }

    @Override
    protected float guardBreakDamage() {
        return 26.0F;
    }

    @Override
    protected boolean isCommitted(int state) {
        return super.isCommitted(state) || state == ST_GRAB || state == ST_HOLD;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        int st = getCombatState();
        if (st == ST_GRAB || st == ST_HOLD) {
            amount *= 0.7F;   // mentre afferra e' difficile da scalfire
        }
        boolean result = super.hurt(source, amount);
        if (result && !this.level().isClientSide && grabbed != null && source.getEntity() == grabbed) {
            holdDamage += amount;
            if (holdDamage >= this.getMaxHealth() * holdBreakFraction()) {   // un colpo (o piu') abbastanza forte spezza la presa
                releaseGrab();
                setCombatState(ST_STAGGER, 0);
            }
        }
        return result;
    }

    // ------------------------------------------------------------------ presa
    @Nullable
    public LivingEntity getGrabbed() {
        return grabbed;
    }

    public void beginGrab(LivingEntity victim) {
        this.grabbed = victim;
        this.holdDamage = 0.0F;
    }

    public void releaseGrab() {
        this.grabbed = null;
        this.holdDamage = 0.0F;
    }

    /** Direzione orizzontale in cui guarda Anissa. */
    public Vec3 flatLook() {
        double yaw = this.getYRot() * Mth.DEG_TO_RAD;
        return new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
    }

    /** Tiene la vittima davanti ad Anissa, un po' sollevata da terra (da chiamare ogni tick, solo server). */
    public void holdVictim() {
        LivingEntity v = grabbed;
        if (v == null) {
            return;
        }
        Vec3 hold = this.position().add(flatLook().scale(0.95D)).add(0.0D, 0.35D, 0.0D);
        Vec3 delta = hold.subtract(v.position());
        if (delta.length() > 9.0D) {      // troppo lontano: la presa e' persa
            releaseGrab();
            return;
        }
        v.setDeltaMovement(delta.scale(0.9D));
        v.hurtMarked = true;
        v.fallDistance = 0.0F;
        if (v instanceof Player) {
            v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 9, false, false, false));
        }
    }

    // ------------------------------------------------------------------ bersagli scagliati
    /** Segue una vittima appena lanciata: se si schianta (muro o suolo) subisce danni extra. */
    public void trackThrown(LivingEntity victim, double speed) {
        thrown.add(new Thrown(victim, speed));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            tickThrown();
        }
    }

    private void tickThrown() {
        if (thrown.isEmpty()) {
            return;
        }
        Iterator<Thrown> it = thrown.iterator();
        while (it.hasNext()) {
            Thrown th = it.next();
            LivingEntity v = th.victim;
            th.ticks++;
            if (!v.isAlive() || th.ticks > 40 || v.level() != this.level()) {
                it.remove();
                continue;
            }
            Vec3 pos = v.position();
            double speed = pos.distanceTo(th.last);
            if (th.ticks >= 2 && th.lastSpeed > 0.9D && speed < th.lastSpeed * 0.45D) {
                float dmg = (float) Math.min(24.0D, th.lastSpeed * 5.0D);
                v.invulnerableTime = 0;
                v.hurt(this.damageSources().mobAttack(this), dmg);
                if (this.level() instanceof ServerLevel server) {
                    CombatFx.impact(server, pos.add(0.0D, v.getBbHeight() * 0.5D, 0.0D));
                }
                it.remove();
                continue;
            }
            th.last = pos;
            th.lastSpeed = speed;
        }
    }

    private static final class Thrown {
        final LivingEntity victim;
        Vec3 last;
        double lastSpeed;
        int ticks;

        Thrown(LivingEntity victim, double speed) {
            this.victim = victim;
            this.last = victim.position();
            this.lastSpeed = 0.0D;
        }
    }
}
