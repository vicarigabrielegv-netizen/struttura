package com.viltrumites.entity.ai;

import com.viltrumites.entity.AnissaEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

/**
 * IA di Anissa: piu' pratica e aggressiva del Viltrumita normale.
 *
 *  - combo da 4 colpi veloci che tengono il bersaglio a portata, poi spesso passa alla presa
 *  - PRESA (ST_GRAB -> ST_HOLD): afferra il bersaglio (aggira lo scudo) e poi sceglie
 *      a) lancio: lo scaglia lontano, con danno extra se si schianta;
 *      b) combo a catena: 2-4 colpi (pugni, ginocchiata) chiusi da montante, schianto a terra o lancio
 *  - volo molto piu' veloce: intercetta la traiettoria del bersaglio e gli resta alle spalle
 *  - sotto meta' vita (furia) afferra piu' spesso e riposa meno
 */
public class AnissaCombatGoal extends ViltrumiteCombatGoal {
    private static final double THROW_UP = 0.28D;

    protected final AnissaEntity anissa;

    protected int grabCooldown = 40;
    protected int chainHits;
    protected int chainIdx;
    protected int finisher = 5;
    protected boolean released;

    // stima della velocita' del bersaglio (il server non conosce quella dei giocatori)
    private LivingEntity trackedTarget;
    private Vec3 lastTargetPos;
    private Vec3 targetVel = Vec3.ZERO;

    public AnissaCombatGoal(AnissaEntity mob) {
        super(mob);
        this.anissa = mob;
        this.attackCooldown = 8;
        this.heavyCooldown = 40;
    }

    @Override
    public void stop() {
        anissa.releaseGrab();
        released = false;
        super.stop();
    }

    @Override
    public void tick() {
        LivingEntity t = mob.getTarget();
        if (t != null) {
            Vec3 pos = t.position();
            if (trackedTarget == t && lastTargetPos != null) {
                targetVel = targetVel.scale(0.5D).add(pos.subtract(lastTargetPos).scale(0.5D));
            } else {
                targetVel = Vec3.ZERO;
                trackedTarget = t;
            }
            lastTargetPos = pos;
        }
        super.tick();
    }

    // ------------------------------------------------------------------ parametri
    @Override
    protected double speedMul() {
        return anissa.isEnraged() ? 1.9D : 1.7D;
    }

    @Override
    protected boolean isBusy(int state) {
        return super.isBusy(state) || state == ViltrumiteEntity.ST_GRAB || state == ViltrumiteEntity.ST_HOLD;
    }

    protected float base() {
        return (float) mob.getAttributeValue(Attributes.ATTACK_DAMAGE);
    }

    protected boolean canGrab(LivingEntity t) {
        return t.isAlive() && !t.isSpectator() && !(t instanceof ViltrumiteEntity);
    }

    protected int pause(int min, int rnd) {
        int v = min + mob.getRandom().nextInt(rnd + 1);
        return anissa.isEnraged() ? (int) (v * 0.65F) : v;
    }

    // ------------------------------------------------------------------ neutro: inseguimento aggressivo
    @Override
    protected void tickNeutral(LivingEntity t, Vec3 diff, double dist, boolean targetAir) {
        boolean flying = mob.isFlying();
        boolean rage = anissa.isEnraged();
        if (grabCooldown > 0) {
            grabCooldown--;
        }

        // contrattacco dopo schivata / parata: presa se si copre, altrimenti combo
        if (mob.counterReady) {
            mob.counterReady = false;
            if (dist < 5.0D) {
                if (grabCooldown <= 0 && canGrab(t) && (t.isBlocking() || mob.getRandom().nextFloat() < 0.3F)) {
                    startGrab(diff, dist);
                } else {
                    startLight(0, diff, dist);
                }
                return;
            }
        }

        // carica in volo: parte prima e piu' spesso del Viltrumita normale
        if (flying && dashCooldown <= 0 && dist > 7.0D && dist < 60.0D && mob.getRandom().nextFloat() < 0.10F) {
            dashCooldown = rage ? 35 : 50;
            mob.setCombatState(ViltrumiteEntity.ST_DASH, 0);
            if (mob.level() instanceof ServerLevel server) {
                CombatFx.dashStart(server, mob.position());
            }
            return;
        }

        if (--strafeTimer <= 0) {
            strafeTimer = 15 + mob.getRandom().nextInt(20);
            strafeSign = mob.getRandom().nextBoolean() ? 1.0D : -1.0D;
        }
        Vec3 horiz = new Vec3(diff.x, 0.0D, diff.z);
        horiz = horiz.lengthSqr() > 1.0E-4D ? horiz.normalize() : mob.getLookAngle();
        Vec3 side = new Vec3(-horiz.z, 0.0D, horiz.x).scale(strafeSign);
        double tspeed = targetVel.length();

        if (flying) {
            Vec3 aim = center(t);
            if (tspeed > 0.35D) {
                // bersaglio veloce: lo intercetta e gli resta alle spalle
                Vec3 lead = targetVel.scale(Math.min(8.0D, 2.0D + dist * 0.25D));
                aim = aim.add(lead).subtract(targetVel.normalize().scale(1.6D));
            } else {
                double hover = (!targetAir && airHold > 0) ? 1.4D : 0.0D;
                aim = aim.subtract(horiz.scale(1.8D)).add(side.scale(1.2D)).add(0.0D, hover, 0.0D);
            }
            double spd = dist > 25.0D ? 1.35D : dist > 10.0D ? 0.95D : 0.55D;
            spd = Math.max(spd, tspeed * 1.15D / speedMul() + 0.1D);
            flyToward(aim, spd, 0.4D);
        } else if (dist > 2.8D) {
            mob.getNavigation().moveTo(t, 1.6D);
        } else {
            mob.getNavigation().stop();
            mob.getMoveControl().strafe(dist < 1.6D ? -0.3F : 0.35F, (float) strafeSign * 0.8F);
        }

        if (attackCooldown <= 0 && dist <= 3.6D) {
            chooseAttack(t, diff, dist);
        }
    }

    @Override
    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        boolean blocking = t.isBlocking();
        float r = mob.getRandom().nextFloat();
        boolean grab = grabCooldown <= 0 && canGrab(t);
        float grabChance = blocking ? 0.7F : (anissa.isEnraged() ? 0.34F : 0.24F);
        if (grab && r < grabChance) {
            startGrab(diff, dist);
        } else if (blocking && heavyCooldown <= 0) {
            heavyCooldown = 40;
            startHeavy(1);                       // rompi-scudo
        } else if (!blocking && heavyCooldown <= 0 && r > 0.9F) {
            heavyCooldown = 90;
            startHeavy(0);                       // schianto a due mani
        } else {
            startLight(0, diff, dist);
        }
    }

    // ------------------------------------------------------------------ combo veloce (4 colpi)
    @Override
    protected void tickLight(LivingEntity t, Vec3 diff, double dist) {
        int tick = mob.getStateTick();
        int sub = mob.getCombatSub();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_LIGHT, sub);

        if (tick < hit && dist > 2.0D) {
            if (mob.isFlying()) {
                flyToward(center(t), 0.55D, 0.45D);
            } else {
                mob.getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), 1.6D);
            }
        }
        if (tick == hit) {
            doLightHit(t, diff, dist, sub);
        }
        if (tick >= mob.stateDuration(ViltrumiteEntity.ST_LIGHT, sub)) {
            boolean last = sub >= 3;
            boolean cont = !last && dist < 4.6D && !mob.comboBroken
                    && mob.getRandom().nextFloat() < (hitThisSwing ? 0.95F : 0.55F);
            mob.comboBroken = false;
            if (cont) {
                startLight(sub + 1, diff, dist);
            } else if (hitThisSwing && sub >= 1 && grabCooldown <= 0 && canGrab(t) && mob.getRandom().nextFloat() < 0.35F) {
                startGrab(diff, dist);           // combo -> presa
            } else {
                mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
                attackCooldown = pause(8, 8) + (last ? 8 : 0);
            }
        }
    }

    @Override
    protected void doLightHit(LivingEntity t, Vec3 diff, double dist, int sub) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 dir = diff.lengthSqr() > 1.0E-4D ? diff.normalize() : mob.getLookAngle();
        Vec3 impact = center(mob).add(dir.scale(Math.min(dist, 1.6D))).add(0.0D, 0.2D, 0.0D);
        if (dist > 4.0D || !mob.hasLineOfSight(t)) {
            CombatFx.whiff(server, impact);
            return;
        }
        boolean fin = sub >= 3;
        t.invulnerableTime = 0;      // i colpi veloci non vengono annullati dall'invulnerabilita' post-colpo
        boolean ok = t.hurt(mob.damageSources().mobAttack(mob), base() * (fin ? 1.3F : 0.8F));
        hitThisSwing = ok;
        if (ok) {
            CombatFx.hit(server, impact, fin ? 2 : 0);
            double kb = fin ? 1.5D : 0.15D;  // i primi colpi tengono il bersaglio a portata, l'ultimo lo spedisce via
            double up = fin ? 0.3D : 0.0D;
            ViltrumiteEntity.push(t, dir.multiply(1.0D, 0.0D, 1.0D).normalize().scale(kb).add(0.0D, up, 0.0D));
        } else {
            CombatFx.whiff(server, impact);
        }
    }

    @Override
    protected void tickHeavy(LivingEntity t, Vec3 diff, double dist) {
        super.tickHeavy(t, diff, dist);
        if (mob.getCombatState() == ViltrumiteEntity.ST_NEUTRAL) {
            attackCooldown = pause(18, 10);
        }
    }

    // ------------------------------------------------------------------ presa
    protected void startGrab(Vec3 diff, double dist) {
        mob.setCombatState(ViltrumiteEntity.ST_GRAB, 0);
        grabCooldown = (anissa.isEnraged() ? 90 : 140) + mob.getRandom().nextInt(60);
        lunge(diff, dist, mob.isFlying() ? 0.8D : 0.55D);
    }

    @Override
    protected void tickCustom(LivingEntity t, Vec3 diff, double dist) {
        int st = mob.getCombatState();
        if (st == ViltrumiteEntity.ST_GRAB) {
            tickGrab(t, dist);
        } else if (st == ViltrumiteEntity.ST_HOLD) {
            tickHold(diff);
        }
    }

    private void tickGrab(LivingEntity t, double dist) {
        int tick = mob.getStateTick();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_GRAB, 0);
        if (tick < hit && dist > 1.6D) {
            if (mob.isFlying()) {
                flyToward(center(t), 0.9D, 0.6D);
            } else {
                mob.getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), 1.9D);
            }
        }
        if (tick == hit) {
            if (dist <= 3.3D && mob.hasLineOfSight(t) && canGrab(t)) {
                anissa.beginGrab(t);
                planHold();
                released = false;
                mob.setCombatState(ViltrumiteEntity.ST_HOLD, 0);
                if (mob.level() instanceof ServerLevel server) {
                    CombatFx.grab(server, center(t));
                }
            } else if (mob.level() instanceof ServerLevel server) {
                CombatFx.whiff(server, center(mob).add(anissa.flatLook().scale(1.4D)));
            }
            return;
        }
        if (tick >= mob.stateDuration(ViltrumiteEntity.ST_GRAB, 0)) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            attackCooldown = pause(20, 10);   // presa a vuoto: piccola pausa
        }
    }

    /** Sceglie cosa fare del bersaglio afferrato: lancio diretto oppure catena di colpi + finale. */
    protected void planHold() {
        boolean rage = anissa.isEnraged();
        chainIdx = 0;
        if (mob.getRandom().nextFloat() < (rage ? 0.30F : 0.42F)) {
            chainHits = 0;
            finisher = 5;                                  // lancio
        } else {
            chainHits = 2 + mob.getRandom().nextInt(3) + (rage ? 1 : 0);
            float f = mob.getRandom().nextFloat();
            finisher = f < 0.40F ? 4 : (f < 0.75F ? 6 : 5);   // montante / schianto / lancio
        }
    }

    protected void tickHold(Vec3 diff) {
        LivingEntity v = anissa.getGrabbed();
        if (v != null && !v.isAlive()) {
            anissa.releaseGrab();
            v = null;
        }
        if (v == null && !released) {
            endHold();
            return;
        }
        if (v != null) {
            anissa.holdVictim();
            Vec3 dm = mob.getDeltaMovement();
            mob.getNavigation().stop();
            mob.setDeltaMovement(dm.x * 0.3D, dm.y, dm.z * 0.3D);   // durante la presa resta quasi ferma
        }

        int sub = mob.getCombatSub();
        int tick = mob.getStateTick();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_HOLD, sub);
        int dur = mob.stateDuration(ViltrumiteEntity.ST_HOLD, sub);

        switch (sub) {
            case 0:
                if (tick >= dur) {
                    nextHoldAction();
                }
                break;
            case 1:
            case 2:
            case 3:
                if (tick == hit && v != null) {
                    chainHit(v, sub);
                }
                if (tick >= dur) {
                    nextHoldAction();
                }
                break;
            case 4:
                if (tick == hit && v != null) {
                    doUppercut(v);
                }
                if (tick >= dur) {
                    endHold();
                }
                break;
            case 5:
                if (tick == hit && v != null) {
                    doThrow(v);
                }
                if (tick >= dur) {
                    endHold();
                    dashCooldown = 0;                  // subito all'inseguimento
                }
                break;
            default:
                if (tick == hit && v != null) {
                    doSlam(v);
                }
                if (tick >= dur) {
                    endHold();
                }
                break;
        }
    }

    protected void nextHoldAction() {
        if (chainIdx < chainHits) {
            int sub = 1 + (chainIdx % 3);                // pugno, pugno, ginocchiata, ...
            chainIdx++;
            mob.setCombatState(ViltrumiteEntity.ST_HOLD, sub);
        } else {
            mob.setCombatState(ViltrumiteEntity.ST_HOLD, finisher);
        }
    }

    protected void endHold() {
        anissa.releaseGrab();
        released = false;
        int st = mob.getCombatState();
        if (st == ViltrumiteEntity.ST_HOLD || st == ViltrumiteEntity.ST_GRAB) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
        }
        attackCooldown = pause(14, 8);
    }

    protected void chainHit(LivingEntity v, int sub) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        v.invulnerableTime = 0;
        boolean ok = v.hurt(mob.damageSources().mobAttack(mob), base() * (sub == 3 ? 0.95F : 0.7F));
        Vec3 at = center(v).subtract(anissa.flatLook().scale(0.4D));
        if (ok) {
            CombatFx.hit(server, at, sub == 3 ? 2 : 0);
        } else {
            CombatFx.whiff(server, at);
        }
    }

    protected void doThrow(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 look = anissa.flatLook();
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 1.5F);
        anissa.releaseGrab();
        released = true;
        // se sta volando alto lo scaglia verso il basso, altrimenti in avanti e leggermente in alto
        double up = mob.isFlying() && ViltrumiteEntity.groundDistance(mob) > 3.0D ? -0.15D : THROW_UP;
        Vec3 vel = look.scale(AnissaEntity.THROW_SPEED).add(0.0D, up, 0.0D);
        v.setDeltaMovement(vel);
        v.hurtMarked = true;
        anissa.trackThrown(v, vel.length());
        CombatFx.throwRelease(server, center(v));
    }

    protected void doUppercut(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 look = anissa.flatLook();
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 1.6F);
        anissa.releaseGrab();
        released = true;
        v.setDeltaMovement(look.x * 0.45D, 1.15D, look.z * 0.45D);
        v.hurtMarked = true;
        CombatFx.hit(server, center(v), 2);
        airHold = 70;                                  // lo segue in aria
        takeOff();
    }

    protected void doSlam(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 2.0F);
        anissa.releaseGrab();
        released = true;
        v.setDeltaMovement(0.0D, -1.6D, 0.0D);
        v.hurtMarked = true;
        anissa.trackThrown(v, 1.6D);                   // extra danno quando tocca terra
        CombatFx.slam(server, v.position());
    }
}
