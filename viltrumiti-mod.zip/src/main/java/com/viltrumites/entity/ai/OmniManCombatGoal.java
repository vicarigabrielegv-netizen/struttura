package com.viltrumites.entity.ai;

import com.viltrumites.entity.OmniManEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * IA di Omni-Man: combo di 4 colpi professionale (ritmo piu' lento di Anissa e Conquest), schivate e parate,
 * e la sua presa firma:
 *
 *   PRESA (ST_GRAB) -> TENUTA (ST_HOLD 0) -> SBATTUTO A TERRA (sub 10) -> RAFFICA DI 8 PUGNI (sub 11)
 *        -> SPINTA CHE LO LASCIA ANDARE (sub 12) -> si riprende lo scontro
 *
 * (a volte, al posto della firma, la solita presa di Anissa: lancio, catena di colpi, montante, schianto).
 * Il contrattacco ("alza la mano e ferma il colpo") sta in {@link OmniManEntity}: quando e' in corso (ST_CATCH)
 * questa IA sta ferma.
 */
public class OmniManCombatGoal extends AnissaCombatGoal {
    private final OmniManEntity omni;

    public OmniManCombatGoal(OmniManEntity mob) {
        super(mob);
        this.omni = mob;
    }

    // ------------------------------------------------------------------ parametri
    @Override
    protected double speedMul() {
        return 1.35D;                            // tra un Viltrumita normale (1,0) e Anissa (1,7)
    }

    @Override
    protected boolean isBusy(int state) {
        return super.isBusy(state) || state == ViltrumiteEntity.ST_CATCH;
    }

    @Override
    protected void updateFlight(LivingEntity t, double dist, boolean targetAir) {
        if (mob.getCombatState() == ViltrumiteEntity.ST_CATCH) {
            return;
        }
        super.updateFlight(t, dist, targetAir);
    }

    @Override
    protected void tickCustom(LivingEntity t, Vec3 diff, double dist) {
        if (mob.getCombatState() == ViltrumiteEntity.ST_CATCH) {
            mob.getNavigation().stop();          // il contrattacco e' gestito da OmniManEntity
            return;
        }
        super.tickCustom(t, diff, dist);
    }

    // ------------------------------------------------------------------ scelta dell'attacco
    @Override
    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        boolean blocking = t.isBlocking();
        float r = mob.getRandom().nextFloat();
        boolean grab = grabCooldown <= 0 && canGrab(t);
        float grabChance = blocking ? 0.7F : 0.28F;
        if (grab && r < grabChance) {
            startGrab(diff, dist);
        } else if (blocking && heavyCooldown <= 0) {
            heavyCooldown = 40;
            startHeavy(1);                       // rompi-scudo
        } else if (!blocking && heavyCooldown <= 0 && r > 0.9F) {
            heavyCooldown = 90;
            startHeavy(0);                       // schianto a due mani
        } else {
            startLight(0, diff, dist);
        }
    }

    @Override
    protected void startGrab(Vec3 diff, double dist) {
        super.startGrab(diff, dist);
        grabCooldown = 120 + mob.getRandom().nextInt(60);
    }

    /** Cosa fare del bersaglio afferrato: la presa firma, oppure (a volte) la solita scelta di Anissa. */
    @Override
    protected void planHold() {
        if (mob.getRandom().nextFloat() < 0.65F) {
            chainIdx = 0;
            chainHits = 0;
            finisher = OmniManEntity.SUB_SLAM;
        } else {
            super.planHold();
        }
    }

    // ------------------------------------------------------------------ presa firma
    @Override
    protected void tickHold(Vec3 diff) {
        int sub = mob.getCombatSub();
        if (sub < OmniManEntity.SUB_SLAM) {
            super.tickHold(diff);               // presa, catena di colpi, montante, lancio, schianto: come Anissa
            return;
        }

        LivingEntity v = anissa.getGrabbed();
        if (v != null && !v.isAlive()) {
            anissa.releaseGrab();
            v = null;
        }
        if (v == null && !released) {
            endHold();
            return;
        }
        mob.getNavigation().stop();
        int tick = mob.getStateTick();
        int hit = mob.stateHitTick(ViltrumiteEntity.ST_HOLD, sub);
        int dur = mob.stateDuration(ViltrumiteEntity.ST_HOLD, sub);
        Vec3 pin = GroundPin.point(mob, anissa.flatLook(), 1.15D);

        if (sub == OmniManEntity.SUB_SLAM) {
            if (tick < hit) {
                anissa.holdVictim();             // lo solleva sopra la testa
            } else {
                if (pin == null) {               // niente terreno sotto: ripiega sul lancio normale
                    mob.setCombatState(ViltrumiteEntity.ST_HOLD, 5);
                    return;
                }
                GroundPin.descend(mob);
                if (v != null) {
                    GroundPin.pull(v, pin);
                }
                if (tick == hit && v != null) {
                    slamImpact(v, pin);
                }
            }
            if (tick >= dur) {
                mob.setCombatState(ViltrumiteEntity.ST_HOLD, OmniManEntity.SUB_BARRAGE);
            }
        } else if (sub == OmniManEntity.SUB_BARRAGE) {
            GroundPin.descend(mob);
            if (pin != null && v != null) {
                GroundPin.pull(v, pin);
            }
            int k = tick - OmniManEntity.BARRAGE_FIRST_HIT;
            if (v != null && k >= 0 && k % OmniManEntity.BARRAGE_PERIOD == 0
                    && k / OmniManEntity.BARRAGE_PERIOD < OmniManEntity.BARRAGE_HITS) {
                barrageHit(v, pin, k / OmniManEntity.BARRAGE_PERIOD);
            }
            if (tick >= dur) {
                mob.setCombatState(ViltrumiteEntity.ST_HOLD, OmniManEntity.SUB_SHOVE);
            }
        } else {                                 // SUB_SHOVE
            if (tick == hit && v != null) {
                shove(v);
            }
            if (tick >= dur) {
                endHold();                       // lo ha lasciato andare: si riprende lo scontro
            }
        }
    }

    /** Lo schianto a terra: gran colpo, onda d'urto e crepa nel terreno. */
    private void slamImpact(LivingEntity v, Vec3 pin) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 1.4F);
        CombatFx.slam(server, pin);
        CombatFx.crater(server, pin, GroundPin.groundState(mob.level(), pin), 1.2F);
    }

    /** Uno degli 8 pugni sul bersaglio inchiodato a terra. */
    private void barrageHit(LivingEntity v, Vec3 pin, int index) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        v.invulnerableTime = 0;
        boolean ok = v.hurt(mob.damageSources().mobAttack(mob), base() * 0.5F);
        Vec3 at = center(v);
        if (ok) {
            CombatFx.hit(server, at, 0);
        } else {
            CombatFx.whiff(server, at);
        }
        if (pin != null && index % 2 == 1) {
            CombatFx.crater(server, pin, GroundPin.groundState(mob.level(), pin), 0.4F);
        }
    }

    /** L'ultimo colpo: lo spinge via e lo lascia andare. */
    private void shove(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
        }
        Vec3 look = anissa.flatLook();
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 1.3F);
        anissa.releaseGrab();
        released = true;
        ViltrumiteEntity.push(v, look.scale(1.9D).add(0.0D, 0.3D, 0.0D));
        CombatFx.hit(server, center(v), 2);
        CombatFx.throwRelease(server, center(v));
    }
}
