package com.viltrumites.entity.ai;

import com.viltrumites.client.tail.TailParams;
import com.viltrumites.entity.ThulaEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import com.viltrumites.fx.CombatFx;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * IA di Thula.
 *
 * FASE 1 (a mani nude): combo veloci come quelle di Anissa (4 colpi), schivate e parate frequenti, volo rapido.
 * Niente prese: la sua presa e' la coda.
 *
 * FASE 2 (coda in mano, {@link ThulaEntity#isTailHeld()}):
 *   ROTAZIONE (ST_SPIN): carica (sub 0), gira su se stessa per 1,5 giri con la coda tesa (sub 1), rallenta (sub 2).
 *     La coda spazza un cerchio di raggio {@link TailParams#SPIN_REACH}: chi viene preso subisce un colpo e viene
 *     spinto lontano.
 *   LANCIO (ST_WHIP): carica (sub 0), la coda parte verso il bersaglio fino a {@link TailParams#THROW_REACH}
 *     (sub 1). Se lo manca raggiunge la lunghezza massima e torna in mano (sub 2). Se lo prende (sub 3) lo tira a
 *     se' e poi lo colpisce (sub 4).
 */
public class ThulaCombatGoal extends AnissaCombatGoal {
    /** Ritardo angolare della punta rispetto al corpo che ruota (gradi). */
    private static final float SPIN_LAG = (float) TailParams.SPIN_LAG_DEG;

    private final ThulaEntity thula;

    private int spinCooldown = 100;
    private int whipCooldown = 70;
    private boolean struck;
    private final Map<Integer, Integer> spinHits = new HashMap<>();

    public ThulaCombatGoal(ThulaEntity mob) {
        super(mob);
        this.thula = mob;
        this.attackCooldown = 6;
    }

    @Override
    public void stop() {
        thula.setTailTarget(-1);
        super.stop();
    }

    // ------------------------------------------------------------------ parametri
    @Override
    protected double speedMul() {
        return thula.isTailHeld() ? 1.85D : 1.75D;
    }

    @Override
    protected boolean canGrab(LivingEntity t) {
        return false;                            // niente presa a mani nude: la sua presa e' la coda
    }

    @Override
    protected boolean isBusy(int state) {
        return super.isBusy(state) || state == ViltrumiteEntity.ST_EQUIP || state == ViltrumiteEntity.ST_SPIN
                || state == ViltrumiteEntity.ST_WHIP;
    }

    private boolean tailAction(int state) {
        return state == ViltrumiteEntity.ST_EQUIP || state == ViltrumiteEntity.ST_SPIN || state == ViltrumiteEntity.ST_WHIP;
    }

    @Override
    protected void updateFlight(LivingEntity t, double dist, boolean targetAir) {
        if (tailAction(mob.getCombatState())) {
            return;                              // niente decollo ne' atterraggio a meta' azione
        }
        super.updateFlight(t, dist, targetAir);
    }

    /** Durante il giro il corpo e' pilotato da {@link #tickSpin}: niente rotazione verso il bersaglio. */
    @Override
    protected void faceTarget(Vec3 diff, double hdist) {
        if (mob.getCombatState() == ViltrumiteEntity.ST_SPIN && mob.getCombatSub() == ThulaEntity.SPIN_TURN) {
            return;
        }
        super.faceTarget(diff, hdist);
    }

    // ------------------------------------------------------------------ scelta dell'azione
    @Override
    protected void tickNeutral(LivingEntity t, Vec3 diff, double dist, boolean targetAir) {
        if (spinCooldown > 0) {
            spinCooldown--;
        }
        if (whipCooldown > 0) {
            whipCooldown--;
        }
        if (thula.isTailHeld() && !mob.counterReady && attackCooldown <= 6) {
            if (whipCooldown <= 0 && dist > 4.0D && dist < TailParams.THROW_REACH - 0.8D && mob.hasLineOfSight(t)
                    && mob.getRandom().nextFloat() < 0.09F) {
                startWhip();
                return;
            }
            if (spinCooldown <= 0 && dist < 4.6D && mob.getRandom().nextFloat() < 0.08F) {
                startSpin();
                return;
            }
        }
        super.tickNeutral(t, diff, dist, targetAir);
    }

    @Override
    protected void chooseAttack(LivingEntity t, Vec3 diff, double dist) {
        if (thula.isTailHeld() && spinCooldown <= 0 && mob.getRandom().nextFloat() < 0.35F) {
            startSpin();
            return;
        }
        super.chooseAttack(t, diff, dist);
    }

    @Override
    protected void tickCustom(LivingEntity t, Vec3 diff, double dist) {
        switch (mob.getCombatState()) {
            case ViltrumiteEntity.ST_EQUIP:
                tickEquip();
                break;
            case ViltrumiteEntity.ST_SPIN:
                tickSpin();
                break;
            case ViltrumiteEntity.ST_WHIP:
                tickWhip(t);
                break;
            default:
                super.tickCustom(t, diff, dist);
                break;
        }
    }

    private void holdStill(double keepFlying) {
        mob.getNavigation().stop();
        Vec3 dm = mob.getDeltaMovement();
        mob.setDeltaMovement(dm.x * 0.35D, mob.isFlying() ? dm.y * keepFlying : dm.y, dm.z * 0.35D);
    }

    // ------------------------------------------------------------------ prende la coda in mano
    private void tickEquip() {
        holdStill(0.5D);
        int tick = mob.getStateTick();
        if (tick == 9 && mob.level() instanceof ServerLevel server) {
            CombatFx.grab(server, thula.handPos());          // il momento in cui afferra la treccia
        }
        if (tick >= mob.stateDuration(ViltrumiteEntity.ST_EQUIP, 0)) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            attackCooldown = 8;
        }
    }

    // ------------------------------------------------------------------ rotazione
    private void startSpin() {
        spinCooldown = 120 + mob.getRandom().nextInt(60);
        spinHits.clear();
        mob.getNavigation().stop();
        mob.setCombatState(ViltrumiteEntity.ST_SPIN, ThulaEntity.SPIN_WIND);
    }

    private void tickSpin() {
        holdStill(0.5D);
        int tick = mob.getStateTick();
        int sub = mob.getCombatSub();
        int dur = mob.stateDuration(ViltrumiteEntity.ST_SPIN, sub);

        if (sub == ThulaEntity.SPIN_WIND) {
            if (tick >= dur) {
                spinHits.clear();
                mob.setCombatState(ViltrumiteEntity.ST_SPIN, ThulaEntity.SPIN_TURN);
            }
        } else if (sub == ThulaEntity.SPIN_TURN) {
            float omega = ThulaEntity.SPIN_DEG_PER_TICK * Math.min(1.0F, (tick + 1) / 5.0F);
            float from = mob.getYRot();
            float to = from + omega;
            mob.setYRot(to);
            mob.yBodyRot = to;
            mob.yHeadRot = to;
            // un'impercettibile deriva in avanti: cosi' anche il client fa ruotare il corpo insieme alla testa
            Vec3 drift = anissa.flatLook().scale(0.04D);
            Vec3 dm = mob.getDeltaMovement();
            mob.setDeltaMovement(dm.x + drift.x, dm.y, dm.z + drift.z);
            sweep(from, to, tick);
            if (tick >= dur) {
                mob.setCombatState(ViltrumiteEntity.ST_SPIN, ThulaEntity.SPIN_END);
            }
        } else if (tick >= dur) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
            attackCooldown = pause(18, 10);
        }
    }

    /** La coda spazza il settore tra i due angoli: chi ci sta dentro (entro il raggio) viene colpito e respinto. */
    private void sweep(float yawFrom, float yawTo, int tick) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        double reach = TailParams.SPIN_REACH;
        float tipFrom = yawFrom - SPIN_LAG;
        float tipTo = yawTo - SPIN_LAG;
        Vec3 origin = mob.position();

        if (tick % 3 == 0) {                                       // scia della coda
            double a = (tipTo + 90.0D) * Mth.DEG_TO_RAD;
            Vec3 tip = origin.add(Math.cos(a) * reach * 0.85D, 1.2D, Math.sin(a) * reach * 0.85D);
            CombatFx.whiff(server, tip);
        }

        AABB box = mob.getBoundingBox().inflate(reach + 0.6D, 1.6D, reach + 0.6D);
        for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, box,
                x -> x != mob && x.isAlive() && !x.isSpectator() && !(x instanceof ViltrumiteEntity))) {
            double dx = e.getX() - origin.x;
            double dz = e.getZ() - origin.z;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > reach + e.getBbWidth() * 0.5D || e.getY() + e.getBbHeight() < origin.y - 0.4D || e.getY() > origin.y + 2.6D) {
                continue;
            }
            Integer last = spinHits.get(e.getId());
            if (last != null && tick - last < 16) {
                continue;
            }
            float bearing = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
            float pad = 14.0F + (float) Math.toDegrees(Math.atan2(e.getBbWidth() * 0.5D, Math.max(d, 0.6D)));
            float rel = Mth.wrapDegrees(bearing - tipFrom);
            if (rel < -pad || rel > (tipTo - tipFrom) + pad) {
                continue;
            }
            spinHits.put(e.getId(), tick);
            spinHit(server, e);
        }
    }

    private void spinHit(ServerLevel server, LivingEntity e) {
        boolean blocking = e.isBlocking();
        e.invulnerableTime = 0;
        boolean ok = e.hurt(mob.damageSources().mobAttack(mob), base() * 1.15F);
        Vec3 away = e.position().subtract(mob.position()).multiply(1.0D, 0.0D, 1.0D);
        away = away.lengthSqr() > 1.0E-4D ? away.normalize() : anissa.flatLook();
        ViltrumiteEntity.push(e, away.scale(blocking ? 0.9D : 1.7D).add(0.0D, ok ? 0.4D : 0.2D, 0.0D));
        CombatFx.hit(server, center(e), 1);
    }

    // ------------------------------------------------------------------ lancio della coda
    private void startWhip() {
        whipCooldown = 110 + mob.getRandom().nextInt(60);
        struck = false;
        mob.getNavigation().stop();
        mob.setCombatState(ViltrumiteEntity.ST_WHIP, ThulaEntity.WHIP_WIND);
    }

    private void tickWhip(LivingEntity t) {
        holdStill(0.5D);
        int sub = mob.getCombatSub();
        int tick = mob.getStateTick();
        int dur = mob.stateDuration(ViltrumiteEntity.ST_WHIP, sub);

        switch (sub) {
            case ThulaEntity.WHIP_WIND:
                if (tick >= dur) {
                    launchWhip(t);
                }
                break;
            case ThulaEntity.WHIP_OUT:
                tickWhipOut(tick, dur);
                break;
            case ThulaEntity.WHIP_BACK:
                if (tick >= dur) {
                    endWhip(pause(16, 8));
                }
                break;
            case ThulaEntity.WHIP_REEL:
                tickReel(tick, dur);
                break;
            default:
                tickStrike(tick, dur);
                break;
        }
    }

    /** Blocca la direzione verso il centro del bersaglio e lancia la coda. */
    private void launchWhip(LivingEntity t) {
        Vec3 origin = thula.handPos();
        Vec3 dir = new Vec3(t.getX(), t.getY(0.6D), t.getZ()).subtract(origin);
        double h = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        float yaw = (float) (Mth.atan2(dir.z, dir.x) * (180.0D / Math.PI)) - 90.0F;
        float pitch = (float) (-(Mth.atan2(dir.y, h) * (180.0D / Math.PI)));
        thula.setAim(yaw, pitch);
        mob.setCombatState(ViltrumiteEntity.ST_WHIP, ThulaEntity.WHIP_OUT);
        if (mob.level() instanceof ServerLevel server) {
            CombatFx.whiff(server, origin.add(thula.aimDir().scale(1.2D)));
        }
    }

    private void tickWhipOut(int tick, int dur) {
        Vec3 origin = thula.handPos();
        Vec3 dir = thula.aimDir();
        Vec3 tip = origin.add(dir.scale(TailParams.throwLength(tick)));
        BlockHitResult wall = mob.level().clip(new ClipContext(origin, tip, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, mob));
        if (wall.getType() != HitResult.Type.MISS) {
            tip = wall.getLocation();                                // la coda si ferma contro i blocchi
        }

        LivingEntity victim = null;
        double best = Double.MAX_VALUE;
        AABB area = new AABB(origin, tip).inflate(1.0D);
        for (LivingEntity e : mob.level().getEntitiesOfClass(LivingEntity.class, area,
                x -> x != mob && x.isAlive() && !x.isSpectator() && !(x instanceof ViltrumiteEntity))) {
            Optional<Vec3> hit = e.getBoundingBox().inflate(0.35D).clip(origin, tip);
            if (hit.isPresent()) {
                double d = origin.distanceToSqr(hit.get());
                if (d < best) {
                    best = d;
                    victim = e;
                }
            }
        }
        if (victim != null) {
            catchVictim(victim);
            return;
        }
        if (mob.level() instanceof ServerLevel server && tick % 2 == 0) {
            server.sendParticles(ParticleTypes.CRIT, tip.x, tip.y, tip.z, 2, 0.1D, 0.1D, 0.1D, 0.02D);
        }
        if (tick >= dur) {
            mob.setCombatState(ViltrumiteEntity.ST_WHIP, ThulaEntity.WHIP_BACK);   // ha raggiunto la lunghezza massima
        }
    }

    private void catchVictim(LivingEntity v) {
        anissa.beginGrab(v);
        thula.setTailTarget(v.getId());
        mob.setCombatState(ViltrumiteEntity.ST_WHIP, ThulaEntity.WHIP_REEL);
        if (mob.level() instanceof ServerLevel server) {
            CombatFx.grab(server, center(v));
        }
    }

    /** Il bersaglio agganciato viene tirato verso di lei. */
    private void tickReel(int tick, int dur) {
        LivingEntity v = anissa.getGrabbed();
        if (v == null || !v.isAlive()) {
            endWhip(pause(14, 8));
            return;
        }
        Vec3 hold = mob.position().add(anissa.flatLook().scale(1.2D)).add(0.0D, 0.2D, 0.0D);
        Vec3 delta = hold.subtract(v.position());
        double d = delta.length();
        if (d < 1.4D || tick >= dur) {
            mob.setCombatState(ViltrumiteEntity.ST_WHIP, ThulaEntity.WHIP_STRIKE);
            return;
        }
        double speed = Math.min(1.7D, 0.45D + d * 0.35D);
        v.setDeltaMovement(delta.scale(speed / d));
        v.hurtMarked = true;
        v.fallDistance = 0.0F;
        if (v instanceof Player) {
            v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 9, false, false, false));
        }
    }

    /** Lo tiene davanti a se' e lo colpisce, poi lo lascia andare. */
    private void tickStrike(int tick, int dur) {
        LivingEntity v = anissa.getGrabbed();
        if (v != null && !v.isAlive()) {
            anissa.releaseGrab();
            v = null;
        }
        if (v != null) {
            anissa.holdVictim();
        } else if (!struck) {
            endWhip(pause(14, 8));                   // la presa e' stata spezzata
            return;
        }
        if (tick == mob.stateHitTick(ViltrumiteEntity.ST_WHIP, ThulaEntity.WHIP_STRIKE) && v != null) {
            strike(v);
        }
        if (tick >= dur) {
            endWhip(pause(20, 10));
        }
    }

    private void strike(LivingEntity v) {
        if (!(mob.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 look = anissa.flatLook();
        if (v instanceof Player p && p.isBlocking()) {
            breakShield(p);
            CombatFx.shieldBreak(server, center(p));
        }
        v.invulnerableTime = 0;
        v.hurt(mob.damageSources().mobAttack(mob), base() * 2.2F);
        anissa.releaseGrab();
        struck = true;
        ViltrumiteEntity.push(v, look.scale(1.9D).add(0.0D, 0.35D, 0.0D));
        CombatFx.hit(server, center(v), 2);
        CombatFx.throwRelease(server, center(v));
    }

    private void endWhip(int pauseTicks) {
        anissa.releaseGrab();
        thula.setTailTarget(-1);
        struck = false;
        if (mob.getCombatState() == ViltrumiteEntity.ST_WHIP) {
            mob.setCombatState(ViltrumiteEntity.ST_NEUTRAL, 0);
        }
        attackCooldown = pauseTicks;
    }
}
