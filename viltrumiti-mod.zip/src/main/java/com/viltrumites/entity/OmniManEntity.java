package com.viltrumites.entity;

import com.viltrumites.entity.ai.OmniManCombatGoal;
import com.viltrumites.entity.ai.ViltrumiteCombatGoal;
import com.viltrumites.fx.CombatFx;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Omni-Man, il Viltrumita boss (compare solo con {@code /summon viltrumites:omniman}).
 *
 * Combattente professionale e dinamico, meno veloce di Anissa e Conquest ma potente e resistente. Riusa di Anissa
 * la presa, la barra del boss e l'adattamento della vita ai cuori del giocatore. Le sue specialita':
 *  - CONTRATTACCO (stato ST_CATCH): quando il giocatore lo colpisce in corpo a corpo, ogni tanto Omni-Man alza la
 *    mano, ferma il colpo (nessun danno, il bersaglio resta bloccato un istante), poi lo colpisce e lo respinge
 *    lontano. All'inizio e' raro e diventa piu' frequente man mano che perde vita (vedi {@link #catchChance()});
 *  - PRESA: afferra il giocatore, lo sbatte a terra, lo riempie di pugni (8 colpi) e lo lascia andare con una
 *    spinta, poi riprende lo scontro (ST_HOLD sub 10, 11 e 12; vedi {@link OmniManCombatGoal}).
 */
public class OmniManEntity extends AnissaEntity {
    /** Vita minima (punti, 2 = 1 cuore). */
    public static final double OMNI_BASE_HEALTH = 260.0D;
    /** Cuori che Omni-Man ha SEMPRE in piu' del giocatore piu' robusto vicino. */
    public static final int OMNI_HEARTS_OVER_PLAYER = 15;
    /** Esperienza lasciata alla morte. */
    public static final int XP_REWARD = 1500;
    /** Danni subiti: 0,88 = -12%. */
    public static final float DAMAGE_TAKEN = 0.88F;

    /** Sotto-stati di ST_HOLD propri di Omni-Man. */
    public static final int SUB_SLAM = 10;
    public static final int SUB_BARRAGE = 11;
    public static final int SUB_SHOVE = 12;
    /** Raffica di pugni: primo colpo al tick 6, poi uno ogni 5 tick, 8 colpi in tutto (durata 46). */
    public static final int BARRAGE_FIRST_HIT = 6;
    public static final int BARRAGE_PERIOD = 5;
    public static final int BARRAGE_HITS = 8;

    /** Sotto-stati di ST_CATCH. */
    public static final int CATCH_HAND = 0;
    public static final int CATCH_STRIKE = 1;

    /** Tick che devono passare dall'evocazione prima del primo contrattacco. */
    private static final int INITIAL_CATCH_COOLDOWN = 100;

    private int catchCooldown = INITIAL_CATCH_COOLDOWN;
    private LivingEntity catchTarget;

    public OmniManEntity(EntityType<? extends OmniManEntity> type, Level level) {
        super(type, level);
        this.xpReward = XP_REWARD;
    }

    public static AttributeSupplier.Builder createOmniManAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, OMNI_BASE_HEALTH)
                .add(Attributes.MOVEMENT_SPEED, 0.40D)
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.ARMOR, 16.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.FLYING_SPEED, 1.1D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OmniManCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    // ------------------------------------------------------------------ ganci di Anissa
    @Override
    protected BossEvent.BossBarColor bossBarColor() {
        return BossEvent.BossBarColor.RED;
    }

    @Override
    protected double baseMaxHealth() {
        return OMNI_BASE_HEALTH;
    }

    @Override
    protected int heartsOverPlayer() {
        return OMNI_HEARTS_OVER_PLAYER;
    }

    @Override
    protected float holdBreakFraction() {
        return 0.08F;
    }

    /** Niente "furia" a meta' vita: il suo ritmo resta costante, cresce solo la frequenza del contrattacco. */
    @Override
    public boolean isEnraged() {
        return false;
    }

    // ------------------------------------------------------------------ tempi e parametri
    @Override
    public int stateDuration(int state, int sub) {
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? 14 : 11;               // piu' lento di Anissa (13/10) e Conquest (11/8)
            case ST_CATCH:
                return sub == CATCH_HAND ? 9 : 14;
            case ST_HOLD:
                if (sub == SUB_SLAM) {
                    return 18;
                } else if (sub == SUB_BARRAGE) {
                    return BARRAGE_FIRST_HIT + BARRAGE_PERIOD * (BARRAGE_HITS - 1) + 5;
                } else if (sub == SUB_SHOVE) {
                    return 16;
                }
                return super.stateDuration(state, sub);
            default:
                return super.stateDuration(state, sub);
        }
    }

    @Override
    public int stateHitTick(int state, int sub) {
        switch (state) {
            case ST_LIGHT:
                return sub >= 3 ? 6 : 5;
            case ST_CATCH:
                return CATCH_STRIKE == sub ? 6 : 0;
            case ST_HOLD:
                if (sub == SUB_SLAM) {
                    return 10;
                } else if (sub == SUB_BARRAGE) {
                    return BARRAGE_FIRST_HIT;
                } else if (sub == SUB_SHOVE) {
                    return 7;
                }
                return super.stateHitTick(state, sub);
            default:
                return super.stateHitTick(state, sub);
        }
    }

    @Override
    protected float dodgeChance(boolean projectile) {
        return projectile ? 0.7F : (isFlying() ? 0.5F : 0.4F);
    }

    @Override
    protected float guardChance() {
        return 0.30F;
    }

    @Override
    protected int dodgeCooldownTicks() {
        return 36;
    }

    @Override
    protected float dodgeCounterChance() {
        return 0.75F;
    }

    @Override
    protected float guardCounterChance() {
        return 0.7F;
    }

    @Override
    protected int guardBreakHits() {
        return 6;
    }

    @Override
    protected float guardBreakDamage() {
        return 28.0F;
    }

    @Override
    protected boolean isCommitted(int state) {
        return super.isCommitted(state) || state == ST_CATCH;
    }

    // ------------------------------------------------------------------ contrattacco
    /** Probabilita' di fermare un colpo: rara all'inizio, sempre piu' frequente man mano che perde vita. */
    private float catchChance() {
        float f = this.getHealth() / this.getMaxHealth();
        return f > 0.75F ? 0.16F : f > 0.5F ? 0.24F : f > 0.25F ? 0.32F : 0.40F;
    }

    /** Pausa minima (tick) tra due contrattacchi: 13 s all'inizio, 5,5 s alla fine. */
    private int catchCooldownTicks() {
        float f = this.getHealth() / this.getMaxHealth();
        return f > 0.75F ? 260 : f > 0.5F ? 200 : f > 0.25F ? 150 : 110;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (getCombatState() == ST_CATCH) {
                return false;                       // durante il contrattacco non si puo' toccare
            }
            if (tryCatch(source)) {
                return false;                       // colpo fermato
            }
            amount *= DAMAGE_TAKEN;
        }
        return super.hurt(source, amount);
    }

    /** Solo corpo a corpo (niente proiettili), e solo se Omni-Man non e' gia' impegnato in una presa o altro. */
    private boolean tryCatch(DamageSource source) {
        if (catchCooldown > 0 || !this.isAlive()) {
            return false;
        }
        Entity attacker = source.getEntity();
        if (!(attacker instanceof LivingEntity victim) || source.getDirectEntity() != attacker
                || attacker instanceof ViltrumiteEntity) {
            return false;
        }
        int st = getCombatState();
        if (st != ST_NEUTRAL && st != ST_LIGHT && st != ST_DASH) {
            return false;
        }
        if (victim.distanceToSqr(this) > 36.0D || this.random.nextFloat() >= catchChance()) {
            return false;
        }
        startCatch(victim);
        return true;
    }

    private void startCatch(LivingEntity victim) {
        this.catchTarget = victim;
        this.catchCooldown = catchCooldownTicks();
        if (this.getTarget() == null && !(victim instanceof Player p && p.getAbilities().invulnerable)) {
            this.setTarget(victim);
        }
        this.setCombatState(ST_CATCH, CATCH_HAND);
        this.getNavigation().stop();
        faceEntity(victim);
        if (this.level() instanceof ServerLevel server) {
            Vec3 hand = this.position().add(0.0D, this.getBbHeight() * 0.7D, 0.0D).add(this.flatLook().scale(0.9D));
            CombatFx.parry(server, hand, true);
        }
        this.level().broadcastEntityEvent(this, EVT_PARRY);
    }

    private void faceEntity(LivingEntity v) {
        double dx = v.getX() - this.getX();
        double dz = v.getZ() - this.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            if (catchCooldown > 0) {
                catchCooldown--;
            }
            tickCatch();
        }
    }

    private void tickCatch() {
        if (getCombatState() != ST_CATCH) {
            catchTarget = null;
            return;
        }
        LivingEntity v = catchTarget;
        if (v == null || !v.isAlive() || v.isRemoved()) {
            setCombatState(ST_NEUTRAL, 0);
            catchTarget = null;
            return;
        }
        faceEntity(v);
        this.getNavigation().stop();
        Vec3 dm = this.getDeltaMovement();
        this.setDeltaMovement(dm.x * 0.3D, isFlying() ? dm.y * 0.3D : dm.y, dm.z * 0.3D);

        // chi ha attaccato resta bloccato dalla mano alzata
        v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 9, false, false, false));

        int sub = getCombatSub();
        int tick = getStateTick();
        if (sub == CATCH_HAND) {
            if (v instanceof Player p) {
                p.resetAttackStrengthTicker();      // il colpo e' annullato: il prossimo parte da zero
            }
            if (tick >= stateDuration(ST_CATCH, CATCH_HAND)) {
                setCombatState(ST_CATCH, CATCH_STRIKE);
            }
        } else {
            if (tick == stateHitTick(ST_CATCH, CATCH_STRIKE)) {
                counterStrike(v);
            }
            if (tick >= stateDuration(ST_CATCH, CATCH_STRIKE)) {
                setCombatState(ST_NEUTRAL, 0);
                catchTarget = null;
            }
        }
    }

    /** La risposta: gran colpo e bersaglio respinto lontano. */
    private void counterStrike(LivingEntity v) {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        Vec3 away = v.position().subtract(this.position()).multiply(1.0D, 0.0D, 1.0D);
        away = away.lengthSqr() > 1.0E-4D ? away.normalize() : this.flatLook();
        Vec3 at = v.position().add(0.0D, v.getBbHeight() * 0.6D, 0.0D).subtract(away.scale(0.3D));
        if (v instanceof Player p && p.isBlocking()) {
            ViltrumiteCombatGoal.breakShield(p);
            CombatFx.shieldBreak(server, at);
        }
        v.invulnerableTime = 0;
        float damage = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE) * 1.5F;
        if (v.hurt(this.damageSources().mobAttack(this), damage)) {
            push(v, away.scale(2.0D).add(0.0D, 0.35D, 0.0D));
        }
        CombatFx.hit(server, at, 2);
    }
}
