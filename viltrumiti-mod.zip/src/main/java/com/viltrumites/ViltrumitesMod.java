package com.viltrumites;

import com.viltrumites.registry.ModEntities;
import com.viltrumites.registry.ModItems;
import com.viltrumites.registry.ModStructures;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ViltrumitesMod.MOD_ID)
public class ViltrumitesMod {
    public static final String MOD_ID = "viltrumites";

    public ViltrumitesMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModStructures.STRUCTURE_TYPES.register(bus);
        ModStructures.STRUCTURE_PIECES.register(bus);
    }
}
