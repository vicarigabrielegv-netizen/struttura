package com.viltrumites.registry;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.AnissaEntity;
import com.viltrumites.entity.ConquestEntity;
import com.viltrumites.entity.OmniManEntity;
import com.viltrumites.entity.ThulaEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    private ModEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ViltrumitesMod.MOD_ID);

    public static final RegistryObject<EntityType<ViltrumiteEntity>> VILTRUMITE = ENTITIES.register("viltrumite",
            () -> EntityType.Builder.of(ViltrumiteEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "viltrumite").toString()));

    /** Boss: si evoca solo con /summon viltrumites:anissa (nessun uovo generatore). */
    public static final RegistryObject<EntityType<AnissaEntity>> ANISSA = ENTITIES.register("anissa",
            () -> EntityType.Builder.of(AnissaEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.8F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "anissa").toString()));

    /** Boss: si evoca solo con /summon viltrumites:conquest. Alto 2,45 blocchi (il modello ha scala 0,9375). */
    public static final RegistryObject<EntityType<ConquestEntity>> CONQUEST = ENTITIES.register("conquest",
            () -> EntityType.Builder.of(ConquestEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.45F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "conquest").toString()));

    /** Boss: si evoca solo con /summon viltrumites:omniman. Alto 1,97 blocchi (il modello ha scala 0,9375). */
    public static final RegistryObject<EntityType<OmniManEntity>> OMNIMAN = ENTITIES.register("omniman",
            () -> EntityType.Builder.of(OmniManEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 1.97F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "omniman").toString()));

    /** Mini-boss: si evoca solo con /summon viltrumites:thula. Alta 1,88 blocchi come il giocatore (scala 0,9375). */
    public static final RegistryObject<EntityType<ThulaEntity>> THULA = ENTITIES.register("thula",
            () -> EntityType.Builder.of(ThulaEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.88F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "thula").toString()));
}
