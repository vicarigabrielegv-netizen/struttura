package com.viltrumites.registry;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.world.GuardiansHqPiece;
import com.viltrumites.world.GuardiansHqStructure;
import com.viltrumites.world.GuardiansTunnelPiece;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModStructures {
    private ModStructures() {}

    public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES =
            DeferredRegister.create(Registries.STRUCTURE_TYPE, ViltrumitesMod.MOD_ID);

    public static final DeferredRegister<StructurePieceType> STRUCTURE_PIECES =
            DeferredRegister.create(Registries.STRUCTURE_PIECE, ViltrumitesMod.MOD_ID);

    /** Tipo di struttura "viltrumites:guardians_hq" (la base dei Guardiani del Globo). */
    public static final RegistryObject<StructureType<GuardiansHqStructure>> GUARDIANS_HQ =
            STRUCTURE_TYPES.register("guardians_hq", () -> () -> GuardiansHqStructure.CODEC);

    /** Pezzo: il template della base. */
    public static final RegistryObject<StructurePieceType> GUARDIANS_HQ_PIECE =
            STRUCTURE_PIECES.register("guardians_hq",
                    () -> (StructurePieceType.StructureTemplateType) GuardiansHqPiece::new);

    /** Pezzo: la rampa che porta dall'ingresso alla superficie. */
    public static final RegistryObject<StructurePieceType> GUARDIANS_TUNNEL_PIECE =
            STRUCTURE_PIECES.register("guardians_tunnel",
                    () -> (StructurePieceType.ContextlessType) GuardiansTunnelPiece::new);
}
