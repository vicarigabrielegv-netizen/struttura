package com.viltrumites.registry;

import com.viltrumites.ViltrumitesMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ViltrumitesMod.MOD_ID);

    public static final RegistryObject<Item> VILTRUMITE_SPAWN_EGG = ITEMS.register("viltrumite_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VILTRUMITE, 0xF0F0F0, 0x8A9697, new Item.Properties()));
}
