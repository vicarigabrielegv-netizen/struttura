package com.viltrumites.client.tail;

import java.util.Arrays;

/**
 * Fisica della coda di Thula: una corda di 22 punti (20 anelli di treccia + 2 della lama) integrata con Verlet
 * a posizioni, in coordinate di mondo.
 *
 *  - vincoli di distanza (la corda non si allunga) e di piegatura con rigidita' {@link TailParams#STIFFNESS};
 *  - gravita' (la punta, con la lama, pesa di piu'), smorzamento e un leggero vento;
 *  - i punti "fissati" (pin) seguono un bersaglio: i primi due stanno sulla testa, in fase 2 un punto sta nella
 *    mano; per il lancio e la rotazione i punti vengono disposti dal codice ({@link #layoutLine},
 *    {@link #layoutSpin}) e al rilascio mantengono la velocita' (la coda "frusta" e poi ricade);
 *  - collisione con busto, gambe e testa (scatole orientate) e con il terreno;
 *  - aderenza alla schiena: tende ad appoggiarsi al busto.
 *
 * Nessuna dipendenza da Minecraft. Si usa cosi': ogni frame {@link #clearPins()}, poi {@link #pin}/layout,
 * {@link #setColliders}, e infine {@link #advance(double)} col tempo in tick.
 */
public final class TailRope {
    public static final int N = TailParams.POINTS;

    /** Terreno: quota della superficie solida sotto il punto, o NaN se non c'e'. */
    public interface Ground {
        double top(double x, double y, double z);
    }

    /** Scatola orientata (parte del corpo). Le coordinate locali sono quelle del modello, in blocchi. */
    public static final class Collider {
        /** Locale -> mondo, 3x4 per righe: x' = m0 x + m1 y + m2 z + m3, ecc. */
        public final double[] m = new double[12];
        private final double[] inv = new double[12];
        public double minX, minY, minZ, maxX, maxY, maxZ;
        /** Fattore di scala della trasformazione (locale -> mondo). */
        public double scale = 1.0D;
        /** Se true la treccia viene attirata verso la faccia +z (la schiena) di questa scatola. */
        public boolean adhere;

        /** Imposta la trasformazione (3x4 per righe) e calcola l'inversa. */
        public void setTransform(double[] a) {
            System.arraycopy(a, 0, m, 0, 12);
            double a00 = a[0], a01 = a[1], a02 = a[2], a10 = a[4], a11 = a[5], a12 = a[6];
            double a20 = a[8], a21 = a[9], a22 = a[10];
            double c00 = a11 * a22 - a12 * a21;
            double c01 = a02 * a21 - a01 * a22;
            double c02 = a01 * a12 - a02 * a11;
            double c10 = a12 * a20 - a10 * a22;
            double c11 = a00 * a22 - a02 * a20;
            double c12 = a02 * a10 - a00 * a12;
            double c20 = a10 * a21 - a11 * a20;
            double c21 = a01 * a20 - a00 * a21;
            double c22 = a00 * a11 - a01 * a10;
            double det = a00 * c00 + a01 * c10 + a02 * c20;
            if (Math.abs(det) < 1.0E-12D) {
                det = 1.0E-12D;
            }
            double id = 1.0D / det;
            inv[0] = c00 * id; inv[1] = c01 * id; inv[2] = c02 * id;
            inv[4] = c10 * id; inv[5] = c11 * id; inv[6] = c12 * id;
            inv[8] = c20 * id; inv[9] = c21 * id; inv[10] = c22 * id;
            inv[3] = -(inv[0] * a[3] + inv[1] * a[7] + inv[2] * a[11]);
            inv[7] = -(inv[4] * a[3] + inv[5] * a[7] + inv[6] * a[11]);
            inv[11] = -(inv[8] * a[3] + inv[9] * a[7] + inv[10] * a[11]);
            scale = Math.cbrt(Math.abs(det));
        }

        public void setBox(double loX, double loY, double loZ, double hiX, double hiY, double hiZ) {
            minX = loX; minY = loY; minZ = loZ;
            maxX = hiX; maxY = hiY; maxZ = hiZ;
        }
    }

    // ------------------------------------------------------------------ stato
    public final double[] x = new double[N];
    public final double[] y = new double[N];
    public final double[] z = new double[N];
    private final double[] ox = new double[N];
    private final double[] oy = new double[N];
    private final double[] oz = new double[N];
    private final double[] tx = new double[N];
    private final double[] ty = new double[N];
    private final double[] tz = new double[N];
    private final double[] lx = new double[N];
    private final double[] ly = new double[N];
    private final double[] lz = new double[N];
    private final double[] tw = new double[N];
    private final double[] lw = new double[N];
    private final double[] seg = new double[N - 1];
    private final double[] invMass = new double[N];

    private double braidLen = TailParams.BRAID_NATURAL;
    /** Assottigliamento della sezione quando la treccia e' allungata (1 = naturale). */
    public double thin = 1.0D;
    /** Verso "destra" del corpo, per orientare la sezione della treccia (vettore unitario). */
    public double sideX = 1.0D, sideY = 0.0D, sideZ = 0.0D;

    private boolean hintValid;
    private double hintX, hintY, hintZ, hintYaw;

    private double lastTime = Double.NaN;
    private double lastStep = TailParams.SUBSTEP;
    private boolean initialized;
    private Ground ground;
    private final Collider[] cols = new Collider[8];
    private int nCols;

    public TailRope() {
        setBraidLength(TailParams.BRAID_NATURAL);
        for (int i = 0; i < N; i++) {
            double t = i / (double) (N - 1);
            invMass[i] = 1.0D / (1.0D + 0.6D * t + (i >= TailParams.BLADE_BASE ? 1.2D : 0.0D));
        }
    }

    // ------------------------------------------------------------------ configurazione per frame
    public double getBraidLength() {
        return braidLen;
    }

    /** Lunghezza della treccia (anello 0 -> anello 19) in blocchi; la lama e il legaccio restano di misura fissa. */
    public void setBraidLength(double blocks) {
        braidLen = Math.max(0.2D, blocks);
        double s = braidLen / (TailParams.BRAID_POINTS - 1);
        for (int i = 0; i < TailParams.BRAID_POINTS - 1; i++) {
            seg[i] = s;
        }
        seg[TailParams.BRAID_POINTS - 1] = TailParams.TIE_LEN_PX * TailParams.PX;
        seg[TailParams.BLADE_BASE] = TailParams.BLADE_LEN_PX * TailParams.PX;
    }

    /**
     * Lunghezze con la mano a {@code grip}: i primi {@code grip} segmenti (testa -> mano) misurano
     * {@code headPart} in tutto, i restanti della treccia (mano -> ultimo anello) {@code freePart}.
     */
    public void setSplitLengths(int grip, double headPart, double freePart) {
        int last = TailParams.BRAID_POINTS - 1;
        double a = Math.max(0.05D, headPart) / grip;
        double b = Math.max(0.05D, freePart) / (last - grip);
        for (int i = 0; i < last; i++) {
            seg[i] = i < grip ? a : b;
        }
        braidLen = Math.max(0.2D, headPart) + Math.max(0.05D, freePart);
        seg[last] = TailParams.TIE_LEN_PX * TailParams.PX;
        seg[TailParams.BLADE_BASE] = TailParams.BLADE_LEN_PX * TailParams.PX;
    }

    public double segment(int i) {
        return seg[i];
    }

    public void setSide(double sx, double sy, double sz) {
        double l = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (l > 1.0E-9D) {
            sideX = sx / l;
            sideY = sy / l;
            sideZ = sz / l;
        }
    }

    public void setGround(Ground g) {
        this.ground = g;
    }

    public void setColliders(Collider[] list, int count) {
        nCols = Math.min(count, cols.length);
        for (int i = 0; i < nCols; i++) {
            cols[i] = list[i];
        }
    }

    /**
     * Posizione e direzione del corpo (yaw in radianti): al primo frame la corda parte dalla sua forma a riposo
     * invece di cadere dritta in basso (che attraverserebbe il terreno per un frame).
     */
    public void setRestHint(double ex, double ey, double ez, double yaw) {
        hintX = ex;
        hintY = ey;
        hintZ = ez;
        hintYaw = yaw;
        hintValid = true;
    }

    public void clearPins() {
        Arrays.fill(tw, 0.0D);
    }

    /** Fissa il punto {@code i} a un bersaglio; peso 1 = fisso, tra 0 e 1 = lo attira solamente. */
    public void pin(int i, double px, double py, double pz, double w) {
        tx[i] = px;
        ty[i] = py;
        tz[i] = pz;
        tw[i] = w;
    }

    public boolean isPinned(int i) {
        return tw[i] >= 0.999D;
    }

    // ------------------------------------------------------------------ disposizioni cinematiche
    /**
     * Dispone i punti da {@code from} (compreso, gia' fissato dal chiamante) fino alla lama su una linea retta da
     * A a B: la punta della lama finisce in B. {@code sag} = quanto la corda si incurva verso il basso (blocchi).
     */
    public void layoutLine(int from, double ax, double ay, double az, double bx, double by, double bz, double sag) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6D) {
            dx = 0.0D; dy = -1.0D; dz = 0.0D; len = 1.0E-6D;
        } else {
            dx /= len; dy /= len; dz /= len;
        }
        double bladeLen = seg[TailParams.BLADE_BASE];
        double tieLen = seg[TailParams.BRAID_POINTS - 1];
        // anello 19 e basi della lama
        double e19x = bx - dx * (bladeLen + tieLen), e19y = by - dy * (bladeLen + tieLen), e19z = bz - dz * (bladeLen + tieLen);
        pin(TailParams.BLADE_TIP, bx, by, bz, 1.0D);
        pin(TailParams.BLADE_BASE, bx - dx * bladeLen, by - dy * bladeLen, bz - dz * bladeLen, 1.0D);
        int last = TailParams.BRAID_POINTS - 1;
        pin(last, e19x, e19y, e19z, 1.0D);
        for (int k = from + 1; k < last; k++) {
            double t = (k - from) / (double) (last - from);
            double s = Math.sin(Math.PI * t) * sag;
            pin(k, ax + (e19x - ax) * t, ay + (e19y - ay) * t - s, az + (e19z - az) * t, 1.0D);
        }
    }

    /**
     * Attira dolcemente i punti (dal 2 in poi, se non gia' fissati) verso la forma a riposo, in un sistema che
     * segue solo la direzione del corpo (non la sua inclinazione): cosi' in volo la coda ricade e scia.
     * {@code yaw} = rotazione del corpo in radianti (convenzione di Minecraft: avanti = (-sin, cos)).
     */
    public void layoutRest(double ex, double ey, double ez, double yaw, double strength) {
        setRestHint(ex, ey, ez, yaw);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double w = Math.min(1.0D, strength * TailParams.REST_PULL);
        for (int i = 2; i < N; i++) {
            if (tw[i] > 0.0D) {
                continue;
            }
            double back = TailParams.REST_Z_PX[i] * TailParams.PX;
            pin(i, ex - fx * back, ey + TailParams.REST_Y_PX[i] * TailParams.PX, ez - fz * back, w);
        }
    }

    /**
     * Dispone i punti dopo {@code from} (la mano, in G) su una spirale orizzontale attorno al centro (cx, cz):
     * la coda e' lanciata in fuori dalla rotazione e resta indietro rispetto al senso di rotazione.
     * {@code lag} = ritardo angolare massimo in punta (rad), {@code droop} = quanto cala la punta (blocchi).
     */
    public void layoutSpin(int from, double cx, double cz, double lag, double droop, double w) {
        double gx = tx[from] - cx, gz = tz[from] - cz;
        double r0 = Math.sqrt(gx * gx + gz * gz);
        double a0 = Math.atan2(gz, gx);
        double total = 0.0D;
        for (int k = from; k < N - 1; k++) {
            total += seg[k];
        }
        double s = 0.0D;
        for (int k = from + 1; k < N; k++) {
            s += seg[k - 1];
            double u = s / total;
            double ang = a0 - lag * Math.pow(u, 1.25D);
            double r = r0 + s * 0.985D;
            double px = cx + r * Math.cos(ang);
            double pz = cz + r * Math.sin(ang);
            double py = ty[from] - droop * u * u + 0.05D * Math.sin(u * 9.0D);
            pin(k, px, py, pz, w);
        }
    }

    // ------------------------------------------------------------------ simulazione
    private void init() {
        double fx = -Math.sin(hintYaw), fz = Math.cos(hintYaw);
        double bx = tw[0] > 0.0D ? tx[0] : 0.0D;
        double by = tw[0] > 0.0D ? ty[0] : 0.0D;
        double bz = tw[0] > 0.0D ? tz[0] : 0.0D;
        double dist = 0.0D;
        for (int i = 0; i < N; i++) {
            if (i > 0) {
                dist += seg[i - 1];
            }
            if (tw[i] > 0.0D) {
                x[i] = tx[i];
                y[i] = ty[i];
                z[i] = tz[i];
            } else if (hintValid) {
                double back = TailParams.REST_Z_PX[i] * TailParams.PX;
                x[i] = hintX - fx * back;
                y[i] = hintY + TailParams.REST_Y_PX[i] * TailParams.PX;
                z[i] = hintZ - fz * back;
            } else {
                x[i] = bx;
                y[i] = by - dist;
                z[i] = bz;
            }
            ox[i] = x[i];
            oy[i] = y[i];
            oz[i] = z[i];
        }
        initialized = true;
    }

    /** Porta la simulazione al tempo {@code time} (tick, con parte frazionaria). */
    public void advance(double time) {
        if (!initialized) {
            init();
        }
        double dt = Double.isNaN(lastTime) ? 0.0D : time - lastTime;
        if (dt > 1.0E-6D) {
            if (dt > 2.0D) {
                dt = 2.0D;
            }
            int n = (int) Math.ceil(dt / TailParams.SUBSTEP);
            double h = dt / n;
            for (int s = 1; s <= n; s++) {
                step(h, s / (double) n, 1.0D / n, time - dt + s * h);
            }
            sanitize();
        } else if (Double.isNaN(lastTime)) {
            for (int i = 0; i < N; i++) {
                if (tw[i] >= 0.999D) {
                    x[i] = tx[i]; y[i] = ty[i]; z[i] = tz[i];
                    ox[i] = tx[i]; oy[i] = ty[i]; oz[i] = tz[i];
                }
            }
        }
        lastTime = time;
        for (int i = 0; i < N; i++) {
            lx[i] = tx[i];
            ly[i] = ty[i];
            lz[i] = tz[i];
            lw[i] = tw[i];
        }
    }

    private void sanitize() {
        for (int i = 0; i < N; i++) {
            if (Double.isNaN(x[i]) || Double.isNaN(y[i]) || Double.isNaN(z[i])
                    || Math.abs(x[i]) > 3.0E7D || Math.abs(z[i]) > 3.0E7D || Math.abs(y[i]) > 1.0E5D) {
                initialized = false;
                init();
                return;
            }
        }
    }

    private void step(double h, double alpha, double dAlpha, double t) {
        double vScale = lastStep > 1.0E-9D ? h / lastStep : 1.0D;
        double damp = Math.pow(TailParams.DAMPING_PER_TICK, h);
        double g = TailParams.GRAVITY * TailParams.WEIGHT;
        double maxV = 1.6D * h;

        for (int i = 0; i < N; i++) {
            boolean pinned = tw[i] >= 0.999D;
            double gx = lerpTarget(lx[i], tx[i], alpha, lw[i], tw[i]);
            double gy = lerpTarget(ly[i], ty[i], alpha, lw[i], tw[i]);
            double gz = lerpTarget(lz[i], tz[i], alpha, lw[i], tw[i]);
            if (pinned) {
                double a0 = Math.max(0.0D, alpha - dAlpha);
                ox[i] = lerpTarget(lx[i], tx[i], a0, lw[i], tw[i]);
                oy[i] = lerpTarget(ly[i], ty[i], a0, lw[i], tw[i]);
                oz[i] = lerpTarget(lz[i], tz[i], a0, lw[i], tw[i]);
                x[i] = gx;
                y[i] = gy;
                z[i] = gz;
                continue;
            }
            double vx = (x[i] - ox[i]) * vScale * damp;
            double vy = (y[i] - oy[i]) * vScale * damp;
            double vz = (z[i] - oz[i]) * vScale * damp;
            double sp = Math.sqrt(vx * vx + vy * vy + vz * vz);
            if (sp > maxV) {
                double k = maxV / sp;
                vx *= k; vy *= k; vz *= k;
            }
            double u = i / (double) (N - 1);
            double heavy = 0.7D + 0.9D * u + (i >= TailParams.BLADE_BASE ? 0.6D : 0.0D);
            double wx = Math.sin(t * 0.11D + i * 0.37D) * Math.cos(t * 0.07D);
            double wz = Math.sin(t * 0.09D + i * 0.21D + 1.3D);
            double ax = wx * 0.0022D * TailParams.WIND;
            double az = wz * 0.0022D * TailParams.WIND;
            double ay = -g * heavy;
            ox[i] = x[i];
            oy[i] = y[i];
            oz[i] = z[i];
            x[i] += vx + ax * h * h;
            y[i] += vy + ay * h * h;
            z[i] += vz + az * h * h;
            if (tw[i] > 0.0D) {                 // pin morbido: attira verso il bersaglio
                double k = Math.min(1.0D, tw[i] * h * 4.0D);
                x[i] += (gx - x[i]) * k;
                y[i] += (gy - y[i]) * k;
                z[i] += (gz - z[i]) * k;
            }
        }

        // aderenza alla schiena
        for (int c = 0; c < nCols; c++) {
            if (cols[c].adhere) {
                adhere(cols[c], h);
            }
        }

        for (int it = 0; it < TailParams.ITERATIONS; it++) {
            distances();
            bending();
            for (int i = 2; i < N; i++) {
                if (tw[i] >= 0.999D) {
                    continue;
                }
                for (int c = 0; c < nCols; c++) {
                    collide(i, cols[c]);
                }
                if (ground != null) {
                    double top = ground.top(x[i], y[i], z[i]);
                    double r = radius(i);
                    if (!Double.isNaN(top) && y[i] < top + r) {
                        y[i] = top + r;
                        ox[i] += (x[i] - ox[i]) * 0.35D;      // attrito
                        oz[i] += (z[i] - oz[i]) * 0.35D;
                    }
                }
            }
            for (int i = 0; i < N; i++) {                      // i punti fissi non si spostano mai
                if (tw[i] >= 0.999D) {
                    x[i] = lerpTarget(lx[i], tx[i], alpha, lw[i], tw[i]);
                    y[i] = lerpTarget(ly[i], ty[i], alpha, lw[i], tw[i]);
                    z[i] = lerpTarget(lz[i], tz[i], alpha, lw[i], tw[i]);
                }
            }
        }
        lastStep = h;
    }

    /** Posizione del bersaglio dentro il frame: i punti appena fissati partono direttamente dal bersaglio. */
    private static double lerpTarget(double last, double target, double alpha, double lastW, double w) {
        return lastW < 0.999D ? target : last + (target - last) * alpha;
    }

    /** Raggio della sezione al punto {@code i} (blocchi). */
    public double radius(int i) {
        if (i >= TailParams.BRAID_POINTS) {
            return TailParams.TIE_WIDTH_FACTOR * TailParams.TIP_RADIUS_PX * 0.5D * TailParams.PX * thin;
        }
        double u = i / (double) (TailParams.BRAID_POINTS - 1);
        return (TailParams.ROOT_RADIUS_PX + (TailParams.TIP_RADIUS_PX - TailParams.ROOT_RADIUS_PX) * u) * TailParams.PX * thin;
    }

    private void distances() {
        for (int i = 0; i < N - 1; i++) {
            double dx = x[i + 1] - x[i], dy = y[i + 1] - y[i], dz = z[i + 1] - z[i];
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d < 1.0E-9D) {
                continue;
            }
            double w0 = tw[i] >= 0.999D ? 0.0D : invMass[i];
            double w1 = tw[i + 1] >= 0.999D ? 0.0D : invMass[i + 1];
            double ws = w0 + w1;
            if (ws <= 0.0D) {
                continue;
            }
            double c = (d - seg[i]) / d / ws;
            x[i] += dx * c * w0; y[i] += dy * c * w0; z[i] += dz * c * w0;
            x[i + 1] -= dx * c * w1; y[i + 1] -= dy * c * w1; z[i + 1] -= dz * c * w1;
        }
    }

    /** Rigidita': i punti i e i+2 tendono a restare alla distanza di una corda dritta. La lama e' quasi rigida. */
    private void bending() {
        for (int i = 0; i < N - 2; i++) {
            double stiff = i >= TailParams.BRAID_POINTS - 2 ? 1.0D : Math.min(1.0D, TailParams.STIFFNESS * TailParams.BEND_GAIN);
            double rest = seg[i] + seg[i + 1];
            double dx = x[i + 2] - x[i], dy = y[i + 2] - y[i], dz = z[i + 2] - z[i];
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d < 1.0E-9D || d >= rest) {
                continue;
            }
            double w0 = tw[i] >= 0.999D ? 0.0D : invMass[i];
            double w1 = tw[i + 2] >= 0.999D ? 0.0D : invMass[i + 2];
            double ws = w0 + w1;
            if (ws <= 0.0D) {
                continue;
            }
            double c = (d - rest) / d / ws * stiff;
            x[i] += dx * c * w0; y[i] += dy * c * w0; z[i] += dz * c * w0;
            x[i + 2] -= dx * c * w1; y[i + 2] -= dy * c * w1; z[i + 2] -= dz * c * w1;
        }
    }

    private void adhere(Collider c, double h) {
        double k = TailParams.BACK_ADHERENCE * h * 4.0D;
        for (int i = 2; i < N; i++) {
            if (tw[i] >= 0.999D) {
                continue;
            }
            double[] iv = c.inv;
            double lx = iv[0] * x[i] + iv[1] * y[i] + iv[2] * z[i] + iv[3];
            double ly = iv[4] * x[i] + iv[5] * y[i] + iv[6] * z[i] + iv[7];
            double lz = iv[8] * x[i] + iv[9] * y[i] + iv[10] * z[i] + iv[11];
            double reach = 0.35D / c.scale;
            if (lx > c.minX && lx < c.maxX && ly > c.minY - 0.05D && ly < c.maxY && lz > c.maxZ && lz < c.maxZ + reach) {
                double target = c.maxZ + radius(i) / c.scale + 0.002D;
                double nz = lz + (target - lz) * k;
                setLocal(c, i, lx, ly, nz);
            }
        }
    }

    private void setLocal(Collider c, int i, double lx, double ly, double lz) {
        double[] m = c.m;
        x[i] = m[0] * lx + m[1] * ly + m[2] * lz + m[3];
        y[i] = m[4] * lx + m[5] * ly + m[6] * lz + m[7];
        z[i] = m[8] * lx + m[9] * ly + m[10] * lz + m[11];
    }

    private void collide(int i, Collider c) {
        double[] iv = c.inv;
        double lx = iv[0] * x[i] + iv[1] * y[i] + iv[2] * z[i] + iv[3];
        double ly = iv[4] * x[i] + iv[5] * y[i] + iv[6] * z[i] + iv[7];
        double lz = iv[8] * x[i] + iv[9] * y[i] + iv[10] * z[i] + iv[11];
        double r = radius(i) / c.scale;
        double x0 = c.minX - r, x1 = c.maxX + r, y0 = c.minY - r, y1 = c.maxY + r, z0 = c.minZ - r, z1 = c.maxZ + r;
        if (lx <= x0 || lx >= x1 || ly <= y0 || ly >= y1 || lz <= z0 || lz >= z1) {
            return;
        }
        double dMin = lx - x0;
        int axis = 0;
        double dir = -1.0D;
        double d = x1 - lx;
        if (d < dMin) { dMin = d; axis = 0; dir = 1.0D; }
        d = ly - y0;
        if (d < dMin) { dMin = d; axis = 1; dir = -1.0D; }
        d = y1 - ly;
        if (d < dMin) { dMin = d; axis = 1; dir = 1.0D; }
        d = lz - z0;
        if (d < dMin) { dMin = d; axis = 2; dir = -1.0D; }
        d = z1 - lz;
        if (d < dMin) { dMin = d; axis = 2; dir = 1.0D; }
        if (axis == 0) {
            lx = dir > 0 ? x1 : x0;
        } else if (axis == 1) {
            ly = dir > 0 ? y1 : y0;
        } else {
            lz = dir > 0 ? z1 : z0;
        }
        setLocal(c, i, lx, ly, lz);
    }
}
