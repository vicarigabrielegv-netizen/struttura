package com.viltrumites.client;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ConquestEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Lato client della cinematica di potenziamento di Conquest (fase 2): finche' un Conquest vicino e' nello stato
 * ST_POWERUP la telecamera trema (sempre di piu' fino all'esplosione) e compaiono le bande nere da film
 * sopra e sotto lo schermo. La scena (pose, particelle, battute in chat) e' gestita da {@link ConquestEntity}.
 */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ConquestCinematic {
    private ConquestCinematic() {}

    /** Distanza entro cui la cinematica si vede / si sente. */
    private static final double RANGE = 48.0D;
    /** Altezza di ciascuna banda nera (frazione dello schermo). */
    private static final float BAR_HEIGHT = 0.13F;

    private static float shake;        // intensita' del tremolio (0..1)
    private static float bars;         // quanto sono scese le bande (0..1, con dissolvenza)
    private static float prevBars;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        prevBars = bars;
        float target = 0.0F;
        float sh = 0.0F;
        if (mc.level != null && mc.player != null) {
            for (ConquestEntity c : mc.level.getEntitiesOfClass(ConquestEntity.class,
                    mc.player.getBoundingBox().inflate(RANGE))) {
                if (c.isPoweringUp()) {
                    target = 1.0F;
                    float k = Mth.clamp(c.getStateTick() / (float) ConquestEntity.POWERUP_TICKS, 0.0F, 1.0F);
                    sh = Math.max(sh, 0.15F + 0.85F * k);
                }
            }
        }
        shake = sh;
        bars += (target - bars) * 0.15F;
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (shake <= 0.0F) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        float t = (mc.level != null ? (float) mc.level.getGameTime() : 0.0F) + (float) event.getPartialTick();
        event.setPitch(event.getPitch() + Mth.sin(t * 1.9F) * 0.9F * shake);
        event.setYaw(event.getYaw() + Mth.sin(t * 2.7F + 1.0F) * 0.9F * shake);
        event.setRoll(event.getRoll() + Mth.sin(t * 3.3F + 2.0F) * 1.6F * shake);
    }

    /** Le bande si disegnano prima dell'interfaccia: chat e barra degli oggetti restano leggibili sopra. */
    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Pre event) {
        float b = Mth.lerp(event.getPartialTick(), prevBars, bars);
        if (b < 0.01F) {
            return;
        }
        GuiGraphics g = event.getGuiGraphics();
        int w = g.guiWidth();
        int h = g.guiHeight();
        int bar = (int) (h * BAR_HEIGHT * b);
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);
    }
}
