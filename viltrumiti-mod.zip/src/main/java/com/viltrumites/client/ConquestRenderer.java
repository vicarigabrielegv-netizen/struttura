package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ConquestEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ConquestRenderer extends MobRenderer<ConquestEntity, ConquestModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/conquest.png");
    /** Come il giocatore: il modello (41,8 px) diventa alto 2,45 blocchi. */
    private static final float SCALE = 0.9375F;

    public ConquestRenderer(EntityRendererProvider.Context context) {
        super(context, new ConquestModel(context.bakeLayer(ConquestModel.LAYER)), 0.8F);
    }

    @Override
    protected void scale(ConquestEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(ConquestEntity entity) {
        return TEXTURE;
    }
}
