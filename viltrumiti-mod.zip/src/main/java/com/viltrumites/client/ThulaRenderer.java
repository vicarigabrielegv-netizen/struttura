package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.client.tail.TailMesh;
import com.viltrumites.client.tail.TailParams;
import com.viltrumites.client.tail.TailRope;
import com.viltrumites.entity.ThulaEntity;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/**
 * Renderer di Thula. Disegna il modello e poi la coda: una corda di 22 punti simulata qui (client) ogni frame
 * da {@link TailRope}, con gli attacchi presi dalle trasformazioni vere del modello (retro della testa, mano
 * destra) e le collisioni con testa, busto e gambe. Gli stati di combattimento sincronizzati dal server
 * decidono come si muove la coda:
 *
 *  - fase 1: i capelli pendono dalla testa (primi due punti fissi), con la loro forma a riposo, il vento e
 *    l'aderenza alla schiena;
 *  - fase 2: la mano destra stringe la treccia ({@link TailParams#GRIP_INDEX}); girando, la coda si distende in
 *    un cerchio; nel lancio e' una linea tesa dalla mano alla punta (o al bersaglio agganciato).
 *
 * Quando una disposizione cinematica finisce (la coda smette di girare, torna in mano) i punti conservano la
 * velocita': la coda "frusta" ancora un po' e poi ricade con la fisica normale.
 */
public class ThulaRenderer extends MobRenderer<ThulaEntity, ThulaModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ViltrumitesMod.MOD_ID, "textures/entity/thula.png");
    /** Come il giocatore: il modello (32 px) diventa alto 1,88 blocchi. */
    private static final float SCALE = 0.9375F;

    private static final int G = TailParams.GRIP_INDEX;
    private static final double TIE_AND_BLADE = (TailParams.TIE_LEN_PX + TailParams.BLADE_LEN_PX) * TailParams.PX;
    private static final double NAT_HEAD = TailParams.BRAID_NATURAL * G / (TailParams.BRAID_POINTS - 1);
    private static final double NAT_FREE = TailParams.BRAID_NATURAL - NAT_HEAD;

    private final TailMesh mesh = new TailMesh();
    private final Matrix4f invBase = new Matrix4f();
    private final Matrix4f lHead = new Matrix4f();
    private final Matrix4f lTorso = new Matrix4f();
    private final Matrix4f lArm = new Matrix4f();
    private final Matrix4f lRLeg = new Matrix4f();
    private final Matrix4f lLLeg = new Matrix4f();
    private final Vector4f vec = new Vector4f();
    private final double[] attach = new double[3];
    private final double[] attach2 = new double[3];
    private final double[] grip = new double[3];
    private final double[] tip = new double[3];
    private final double[] affine = new double[12];

    public ThulaRenderer(EntityRendererProvider.Context context) {
        super(context, new ThulaModel(context.bakeLayer(ThulaModel.LAYER)), 0.5F);
    }

    @Override
    protected void scale(ThulaEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    public ResourceLocation getTextureLocation(ThulaEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(ThulaEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        Matrix4f base = new Matrix4f(poseStack.last().pose());   // origine = posizione dell'entita'
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
        if (!entity.isInvisible() && this.model.hasFreshCapture()) {
            renderTail(entity, partialTick, poseStack, buffer, packedLight, base);
        }
    }

    // ------------------------------------------------------------------ utilita'
    /** Punto del modello (pixel, nello spazio di una parte) -> coordinate di mondo (blocchi). */
    private void toWorld(Matrix4f m, double px, double py, double pz, double ex, double ey, double ez, double[] out) {
        vec.set((float) (px / 16.0D), (float) (py / 16.0D), (float) (pz / 16.0D), 1.0F);
        m.transform(vec);
        out[0] = ex + vec.x();
        out[1] = ey + vec.y();
        out[2] = ez + vec.z();
    }

    private void collider(TailRope.Collider c, Matrix4f m, double x0, double y0, double z0, double x1, double y1, double z1,
                          boolean adhere) {
        affine[0] = m.m00(); affine[1] = m.m10(); affine[2] = m.m20(); affine[3] = m.m30();
        affine[4] = m.m01(); affine[5] = m.m11(); affine[6] = m.m21(); affine[7] = m.m31();
        affine[8] = m.m02(); affine[9] = m.m12(); affine[10] = m.m22(); affine[11] = m.m32();
        c.setTransform(affine);
        c.setBox(x0 / 16.0D, y0 / 16.0D, z0 / 16.0D, x1 / 16.0D, y1 / 16.0D, z1 / 16.0D);
        c.adhere = adhere;
    }

    // ------------------------------------------------------------------ la coda
    private void renderTail(ThulaEntity e, float pt, PoseStack ps, MultiBufferSource buf, int light, Matrix4f base) {
        ThulaModel m = this.model;
        invBase.set(base).invert();
        lHead.set(invBase).mul(m.headMat);
        lTorso.set(invBase).mul(m.torsoMat);
        lArm.set(invBase).mul(m.rightArmMat);
        lRLeg.set(invBase).mul(m.rightLegMat);
        lLLeg.set(invBase).mul(m.leftLegMat);

        double ex = Mth.lerp((double) pt, e.xo, e.getX());
        double ey = Mth.lerp((double) pt, e.yo, e.getY());
        double ez = Mth.lerp((double) pt, e.zo, e.getZ());
        double time = e.tickCount + (double) pt;
        double dt = Double.isNaN(e.tailLastTime) ? 0.0D : Mth.clamp(time - e.tailLastTime, 0.0D, 3.0D);
        e.tailLastTime = time;

        TailRope rope = e.tailRope();
        int st = e.getCombatState();
        int sub = e.getCombatSub();
        double tick = e.stateTick + (double) pt;
        boolean held = e.isTailHeld();

        // ---- punti di attacco
        toWorld(lHead, TailParams.ATTACH_PX[0], TailParams.ATTACH_PX[1], TailParams.ATTACH_PX[2], ex, ey, ez, attach);
        toWorld(lHead, TailParams.ATTACH2_PX[0], TailParams.ATTACH2_PX[1], TailParams.ATTACH2_PX[2], ex, ey, ez, attach2);
        toWorld(lArm, 0.0D, 10.0D, 0.0D, ex, ey, ez, grip);

        // ---- cosa fa la coda in questo istante
        double targetHead = held ? TailParams.HEAD_PART : NAT_HEAD;
        double targetFree = held ? TailParams.HELD_FREE : NAT_FREE;
        double gripTarget = held ? 1.0D : 0.0D;
        boolean line = false;
        double lineLen = 0.0D;
        double spinW = 0.0D;
        double sag = 0.05D;

        if (held) {
            if (st == ViltrumiteEntity.ST_EQUIP) {
                gripTarget = tick > 8.0D ? 1.0D : 0.0D;           // la mano raggiunge la treccia a meta' del gesto
            } else if (st == ViltrumiteEntity.ST_SPIN) {
                if (sub == ThulaEntity.SPIN_TURN) {
                    targetFree = TailParams.SPIN_FREE;
                    spinW = Math.min(1.0D, tick / 4.0D);
                } else if (sub == ThulaEntity.SPIN_END) {
                    targetFree = TailParams.SPIN_FREE;
                    spinW = Math.max(0.0D, 1.0D - tick / 3.0D);
                } else {
                    targetFree = TailParams.SPIN_FREE * 0.6D + TailParams.HELD_FREE * 0.4D;
                }
            } else if (st == ViltrumiteEntity.ST_WHIP) {
                if (sub == ThulaEntity.WHIP_OUT || sub == ThulaEntity.WHIP_BACK) {
                    line = true;
                    lineLen = sub == ThulaEntity.WHIP_OUT ? TailParams.throwLength(tick) : TailParams.returnLength(tick);
                    Vec3 d = e.aimDir();
                    tip[0] = grip[0] + d.x * lineLen;
                    tip[1] = grip[1] + d.y * lineLen;
                    tip[2] = grip[2] + d.z * lineLen;
                } else if (sub == ThulaEntity.WHIP_REEL || sub == ThulaEntity.WHIP_STRIKE) {
                    Entity v = e.level().getEntity(e.getTailTarget());
                    if (v != null) {
                        line = true;
                        tip[0] = Mth.lerp((double) pt, v.xo, v.getX());
                        tip[1] = Mth.lerp((double) pt, v.yo, v.getY()) + v.getBbHeight() * 0.6D;
                        tip[2] = Mth.lerp((double) pt, v.zo, v.getZ());
                        sag = 0.12D;
                    }
                }
            }
        }

        // ---- lunghezze (lisciate nel tempo)
        double k = 1.0D - Math.pow(0.7D, dt);
        e.tailHead += (targetHead - e.tailHead) * k;
        e.tailFree += (targetFree - e.tailFree) * k;
        e.tailGrip += (gripTarget - e.tailGrip) * (1.0D - Math.pow(0.55D, dt));
        double head = e.tailHead;
        double free = e.tailFree;
        if (line) {
            double dx = tip[0] - grip[0], dy = tip[1] - grip[1], dz = tip[2] - grip[2];
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            free = Math.max(0.25D, dist - TIE_AND_BLADE);
            head = TailParams.HEAD_PART;
            e.tailFree = free;                                 // al termine la coda parte da questa lunghezza e rientra
        }
        rope.setSplitLengths(G, head, free);
        double ext = (head + free) / TailParams.BRAID_NATURAL;
        rope.thin = Mth.clamp(1.0D / Math.sqrt(Math.max(1.0D, ext)), 0.5D, 1.0D);

        // ---- corpo: collisioni e riferimento per l'orientamento della sezione
        TailRope.Collider[] cols = e.tailColliders();
        collider(cols[0], lTorso, -4.25D, -12.25D, -2.25D, 4.25D, 0.25D, 2.25D, true);
        collider(cols[1], lHead, -4.55D, -8.55D, -4.55D, 4.55D, 0.3D, 4.55D, false);
        collider(cols[2], lRLeg, -2.25D, -0.2D, -2.25D, 2.25D, 12.25D, 2.25D, true);
        collider(cols[3], lLLeg, -2.25D, -0.2D, -2.25D, 2.25D, 12.25D, 2.25D, true);
        rope.setColliders(cols, 4);
        rope.setSide(lTorso.m00(), lTorso.m01(), lTorso.m02());
        final Level level = e.level();
        rope.setGround((x, y, z) -> {
            int bx = Mth.floor(x);
            int bz = Mth.floor(z);
            int by = Mth.floor(y);
            for (int i = 0; i < 2; i++) {
                if (level.getBlockState(new BlockPos(bx, by - i, bz)).blocksMotion()) {
                    return by - i + 1.0D;
                }
            }
            return Double.NaN;
        });

        // ---- vincoli del frame
        rope.clearPins();
        rope.pin(0, attach[0], attach[1], attach[2], 1.0D);
        rope.pin(1, attach2[0], attach2[1], attach2[2], 1.0D);
        double gw = e.tailGrip;
        if (gw > 0.02D || line) {
            rope.pin(G, grip[0], grip[1], grip[2], (gw > 0.97D || line) ? 1.0D : gw);
        }
        if (line) {
            rope.layoutLine(G, grip[0], grip[1], grip[2], tip[0], tip[1], tip[2], sag);
        } else if (spinW > 0.0D) {
            rope.layoutSpin(G, ex, ez, Math.toRadians(TailParams.SPIN_LAG_DEG), 0.22D, spinW);
        }
        double yaw = Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot) * Mth.DEG_TO_RAD;
        rope.setRestHint(ex, ey, ez, yaw);
        if (!line && spinW <= 0.0D) {
            double rest = 1.0D - Math.min(1.0D, gw * 1.1D);
            if (rest > 0.01D) {
                rope.layoutRest(ex, ey, ez, yaw, rest);
            }
        }
        rope.advance(time);

        // ---- disegno
        mesh.build(rope, ex, ey, ez);
        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        Matrix4f pose = ps.last().pose();
        Matrix3f normal = ps.last().normal();
        float[] d = mesh.data;
        for (int q = 0; q < mesh.quads; q++) {
            for (int v = 0; v < 4; v++) {
                int o = (q * 4 + v) * TailMesh.STRIDE;
                vc.vertex(pose, d[o], d[o + 1], d[o + 2])
                        .color(255, 255, 255, 255)
                        .uv(d[o + 3] / TailMesh.ATLAS_W, d[o + 4] / TailMesh.ATLAS_H)
                        .overlayCoords(OverlayTexture.NO_OVERLAY)
                        .uv2(light)
                        .normal(normal, d[o + 5], d[o + 6], d[o + 7])
                        .endVertex();
            }
        }
    }
}
