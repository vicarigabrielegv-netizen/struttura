package com.viltrumites.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ConquestEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Modello di Conquest: stesso rig di Anissa (bacino -> busto -> testa/braccia, bacino -> gambe) ma con le
 * proporzioni dell'editor (testa 10x10x10, busto 13,6x15,6x4,6, braccia 6x16,2x6, gambe 7,8x16,2x6, alto 41,8 px
 * = 2,45 blocchi con la scala 0,9375 del renderer, vedi {@link ConquestRenderer}).
 *
 * Ogni scatola ha le dimensioni UV standard della skin 64x64 (8x12x4 ecc.) ma e' "gonfiata" per asse fino alle
 * dimensioni finali: la mappatura della texture resta quella normale. Gli strati esterni (capelli, giacca, maniche,
 * pantaloni) aggiungono 0,6 px (testa 0,9; manica destra 1,1) alle dimensioni finali.
 * Uguale al rig di tools/generate_assets.py (PARTS_CONQUEST).
 */
public class ConquestModel extends EntityModel<ConquestEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ViltrumitesMod.MOD_ID, "conquest"), "main");

    /** Altezza del bacino (piedi a y = 24) e moltiplicatore dell'abbassamento delle animazioni (gambe piu' lunghe). */
    private static final float PELVIS_Y = 7.8F;
    private static final float DY_MUL = 1.35F;

    private final ModelPart root;
    private final ModelPart pelvis;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public ConquestModel(ModelPart root) {
        this.root = root;
        this.pelvis = root.getChild("pelvis");
        this.torso = pelvis.getChild("torso");
        this.head = torso.getChild("head");
        this.rightArm = torso.getChild("right_arm");
        this.leftArm = torso.getChild("left_arm");
        this.rightLeg = pelvis.getChild("right_leg");
        this.leftLeg = pelvis.getChild("left_leg");
    }

    /**
     * Scatola con UV da (dx, dy, dz) che copre gli estremi finali [lo..hi] (pixel del modello, nel sistema della
     * parte): la crescita per asse e' meta' della differenza; {@code extra} e' il gonfiaggio dello strato esterno.
     */
    private static CubeListBuilder box(int u, int v, float dx, float dy, float dz,
                                       float loX, float loY, float loZ, float hiX, float hiY, float hiZ, float extra) {
        float gx = ((hiX - loX) - dx) / 2.0F;
        float gy = ((hiY - loY) - dy) / 2.0F;
        float gz = ((hiZ - loZ) - dz) / 2.0F;
        return CubeListBuilder.create().texOffs(u, v)
                .addBox(loX + gx, loY + gy, loZ + gz, dx, dy, dz, new CubeDeformation(gx + extra, gy + extra, gz + extra));
    }

    // estremi finali (px): busto 13,6 x 15,6 x 4,6 / testa 10^3 / braccio 6 x 16,2 x 6 / gamba 7,8 x 16,2 x 6
    private static CubeListBuilder torsoBox(int u, int v, float extra) {
        return box(u, v, 8, 12, 4, -6.8F, -15.6F, -2.3F, 6.8F, 0.0F, 2.3F, extra);
    }

    private static CubeListBuilder headBox(int u, int v, float extra) {
        return box(u, v, 8, 8, 8, -5.0F, -10.0F, -5.0F, 5.0F, 0.0F, 5.0F, extra);
    }

    private static CubeListBuilder armBox(int u, int v, float extra) {
        return box(u, v, 4, 12, 4, -3.0F, -1.62F, -3.0F, 3.0F, 14.58F, 3.0F, extra);
    }

    private static CubeListBuilder legBox(int u, int v, float extra) {
        return box(u, v, 4, 12, 4, -3.9F, 0.0F, -3.0F, 3.9F, 16.2F, 3.0F, extra);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition pelvis = root.addOrReplaceChild("pelvis", CubeListBuilder.create(), PartPose.offset(0.0F, PELVIS_Y, 0.0F));

        PartDefinition torso = pelvis.addOrReplaceChild("torso", torsoBox(16, 16, 0.0F), PartPose.ZERO);
        torso.addOrReplaceChild("jacket", torsoBox(16, 32, 0.6F), PartPose.ZERO);

        PartDefinition head = torso.addOrReplaceChild("head", headBox(0, 0, 0.0F), PartPose.offset(0.0F, -15.6F, 0.0F));
        head.addOrReplaceChild("hat", headBox(32, 0, 0.9F), PartPose.ZERO);

        PartDefinition rightArm = torso.addOrReplaceChild("right_arm", armBox(40, 16, 0.0F),
                PartPose.offset(-9.8F, -13.98F, 0.0F));
        rightArm.addOrReplaceChild("right_sleeve", armBox(40, 32, 1.1F), PartPose.ZERO);
        PartDefinition leftArm = torso.addOrReplaceChild("left_arm", armBox(32, 48, 0.0F),
                PartPose.offset(9.8F, -13.98F, 0.0F));
        leftArm.addOrReplaceChild("left_sleeve", armBox(48, 48, 0.6F), PartPose.ZERO);

        PartDefinition rightLeg = pelvis.addOrReplaceChild("right_leg", legBox(0, 16, 0.0F),
                PartPose.offset(-2.9F, 0.0F, 0.0F));
        rightLeg.addOrReplaceChild("right_pants", legBox(0, 32, 0.6F), PartPose.ZERO);
        PartDefinition leftLeg = pelvis.addOrReplaceChild("left_leg", legBox(16, 48, 0.0F),
                PartPose.offset(2.9F, 0.0F, 0.0F));
        leftLeg.addOrReplaceChild("left_pants", legBox(0, 48, 0.6F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(ConquestEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float[] p = ViltrumiteAnimator.compute(entity, partial, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        pelvis.setPos(0.0F, PELVIS_Y + DY_MUL * p[ViltrumiteAnimator.PDY], 0.0F);
        set(pelvis, p, ViltrumiteAnimator.PX);
        set(torso, p, ViltrumiteAnimator.TX);
        set(head, p, ViltrumiteAnimator.HX);
        set(rightArm, p, ViltrumiteAnimator.RAX);
        set(leftArm, p, ViltrumiteAnimator.LAX);
        set(rightLeg, p, ViltrumiteAnimator.RLX);
        set(leftLeg, p, ViltrumiteAnimator.LLX);
    }

    private static void set(ModelPart part, float[] p, int i) {
        part.xRot = p[i];
        part.yRot = p[i + 1];
        part.zRot = p[i + 2];
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
