package com.viltrumites.events;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.client.AnissaModel;
import com.viltrumites.client.AnissaRenderer;
import com.viltrumites.client.ConquestModel;
import com.viltrumites.client.ConquestRenderer;
import com.viltrumites.client.OmniManModel;
import com.viltrumites.client.OmniManRenderer;
import com.viltrumites.client.ThulaModel;
import com.viltrumites.client.ThulaRenderer;
import com.viltrumites.client.ViltrumiteModel;
import com.viltrumites.client.ViltrumiteRenderer;
import com.viltrumites.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ViltrumiteModel.LAYER, ViltrumiteModel::createBodyLayer);
        event.registerLayerDefinition(AnissaModel.LAYER, AnissaModel::createBodyLayer);
        event.registerLayerDefinition(ConquestModel.LAYER, ConquestModel::createBodyLayer);
        event.registerLayerDefinition(OmniManModel.LAYER, OmniManModel::createBodyLayer);
        event.registerLayerDefinition(ThulaModel.LAYER, ThulaModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.VILTRUMITE.get(), ViltrumiteRenderer::new);
        event.registerEntityRenderer(ModEntities.ANISSA.get(), AnissaRenderer::new);
        event.registerEntityRenderer(ModEntities.CONQUEST.get(), ConquestRenderer::new);
        event.registerEntityRenderer(ModEntities.OMNIMAN.get(), OmniManRenderer::new);
        event.registerEntityRenderer(ModEntities.THULA.get(), ThulaRenderer::new);
    }
}
