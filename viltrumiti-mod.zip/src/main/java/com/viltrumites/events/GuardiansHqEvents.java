package com.viltrumites.events;

import com.mojang.brigadier.Command;
import com.viltrumites.ViltrumitesMod;
import com.viltrumites.world.GuardiansHqSite;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Aggancia la scelta della posizione della base ai mondi caricati e aggiunge il comando /viltrumites hq. */
@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GuardiansHqEvents {
    private GuardiansHqEvents() {}

    @SubscribeEvent
    public static void onLevelLoad(LevelEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel level) {
            GuardiansHqSite.register(level);
        }
    }

    @SubscribeEvent
    public static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) {
            GuardiansHqSite.unregister(level);
        }
    }

    /** Solo per operatori (livello 2): dice dove si trova la base in questo mondo, senza doverla cercare. */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("viltrumites")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("hq").executes(context -> locateHq(context.getSource()))));
    }

    private static int locateHq(CommandSourceStack source) {
        ChunkPos pos = GuardiansHqSite.locate(source.getLevel());
        if (pos == null) {
            source.sendFailure(Component.literal("Nessuna base dei Guardiani del Globo in questa dimensione."));
            return 0;
        }
        int x = pos.getMiddleBlockX();
        int z = pos.getMiddleBlockZ();
        source.sendSuccess(() -> Component.literal("Base dei Guardiani del Globo: centro a X=" + x + ", Z=" + z
                + ". E' sotto la superficie: l'ingresso e' sul fianco della montagna, entro circa 130 blocchi dal centro."),
                false);
        return Command.SINGLE_SUCCESS;
    }
}
