package com.viltrumites.events;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.entity.living.ShieldBlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ViltrumitesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ForgeEvents {
    private ForgeEvents() {}

    /** Quando uno scudo (giocatore compreso) para un colpo viltrumita: onda d'urto e contraccolpo. */
    @SubscribeEvent
    public static void onShieldBlock(ShieldBlockEvent event) {
        Entity attacker = event.getDamageSource().getEntity();
        if (attacker instanceof ViltrumiteEntity viltrumite && !viltrumite.level().isClientSide) {
            viltrumite.onBlockedByShield(event.getEntity());
        }
    }
}
