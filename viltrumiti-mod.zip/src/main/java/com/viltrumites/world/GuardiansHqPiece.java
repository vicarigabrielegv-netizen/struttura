package com.viltrumites.world;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.TemplateStructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.templatesystem.BlockIgnoreProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

/** Il template della base (tamburo + corridoio d'ingresso), ruotato attorno al centro del tamburo. */
public class GuardiansHqPiece extends TemplateStructurePiece {
    public static final ResourceLocation TEMPLATE = new ResourceLocation(ViltrumitesMod.MOD_ID, "guardians_hq");
    private static final BlockPos PIVOT = new BlockPos(GuardiansHq.CENTER, 0, GuardiansHq.CENTER);

    /** @param pos angolo (0,0,0) del template nel mondo, prima della rotazione attorno al perno */
    public GuardiansHqPiece(StructureTemplateManager manager, BlockPos pos, Rotation rotation) {
        super(ModStructures.GUARDIANS_HQ_PIECE.get(), 0, manager, TEMPLATE, TEMPLATE.toString(),
                makeSettings(rotation), pos);
    }

    public GuardiansHqPiece(StructureTemplateManager manager, CompoundTag tag) {
        super(ModStructures.GUARDIANS_HQ_PIECE.get(), tag, manager,
                id -> makeSettings(Rotation.valueOf(tag.getString("Rot"))));
    }

    private static StructurePlaceSettings makeSettings(Rotation rotation) {
        return new StructurePlaceSettings()
                .setRotation(rotation)
                .setRotationPivot(PIVOT)
                .setIgnoreEntities(true)
                .addProcessor(BlockIgnoreProcessor.STRUCTURE_BLOCK);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        super.addAdditionalSaveData(context, tag);
        tag.putString("Rot", this.placeSettings.getRotation().name());
    }

    @Override
    protected void handleDataMarker(String marker, BlockPos pos, ServerLevelAccessor level,
                                    RandomSource random, BoundingBox box) {
        // Il template non contiene blocchi dati.
    }
}
