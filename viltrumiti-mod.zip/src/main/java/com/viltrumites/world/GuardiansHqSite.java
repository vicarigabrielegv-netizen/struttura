package com.viltrumites.world;

import com.viltrumites.ViltrumitesMod;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/**
 * Sceglie in modo deterministico (dipende solo dal seed e dai biomi del mondo) l'UNICA casella della griglia
 * "random_spread" dove nasce la base dei Guardiani. Cosi' la base e' unica per mondo, compare anche quando vicino
 * all'origine non ci sono montagne e funziona con qualunque generatore di biomi.
 *
 * Criteri, in ordine di importanza:
 *  1. lontana dall'origine (almeno {@link GuardiansHq#MIN_DISTANCE} blocchi);
 *  2. senza altre strutture attorno: nessun punto di partenza di una struttura che potrebbe nascere in quel bioma
 *     (vanilla o di altre mod) entro {@link GuardiansHq#CLEAR_RANGE} chunk, cosi' non si sovrappongono;
 *  3. in montagna (tag viltrumites:has_structure/guardians_hq_mountains), altrimenti in un altro bioma valido
 *     (tag viltrumites:has_structure/guardians_hq);
 *  4. mai in acqua e mai troppo in basso per nasconderla.
 */
public final class GuardiansHqSite {
    private GuardiansHqSite() {}

    private static final ResourceLocation OUR_SET = new ResourceLocation(ViltrumitesMod.MOD_ID, "guardians_hq");

    /** Stessa griglia del JSON del structure_set: serve solo a calcolare le caselle candidate. */
    private static final RandomSpreadStructurePlacement GRID = new RandomSpreadStructurePlacement(
            GuardiansHq.SPACING, GuardiansHq.SEPARATION, RandomSpreadType.LINEAR, GuardiansHq.SALT);

    private static final TagKey<Biome> MOUNTAINS = TagKey.create(Registries.BIOME,
            new ResourceLocation(ViltrumitesMod.MOD_ID, "has_structure/guardians_hq_mountains"));

    /** Tutto quello che serve per scegliere: lo stesso per la generazione e per il comando di localizzazione. */
    private record Env(ChunkGenerator gen, BiomeSource biomes, RandomState rs, LevelHeightAccessor ha, long seed,
                       Predicate<Holder<Biome>> valid, ChunkGeneratorStructureState state) {}

    private record Cand(ChunkPos pos, boolean mountain, int tier, long rank) {}

    private record Result(long seed, ChunkPos pos) {}

    private static final Map<BiomeSource, Result> CACHE = Collections.synchronizedMap(new WeakHashMap<>());
    /** Stato delle strutture di ogni dimensione caricata (serve per sapere dove sono le altre strutture). */
    private static final Map<BiomeSource, ChunkGeneratorStructureState> STATES = new ConcurrentHashMap<>();

    // ---- agganci con il mondo -------------------------------------------------------------------------------

    public static void register(ServerLevel level) {
        ServerChunkCache cache = level.getChunkSource();
        STATES.put(cache.getGenerator().getBiomeSource(), cache.getGeneratorState());
    }

    public static void unregister(ServerLevel level) {
        BiomeSource source = level.getChunkSource().getGenerator().getBiomeSource();
        STATES.remove(source);
        CACHE.remove(source);
    }

    /** Per la generazione. @return il chunk di partenza della base in questo mondo, o null se non c'e' posto */
    static ChunkPos get(Structure.GenerationContext ctx) {
        Env env = new Env(ctx.chunkGenerator(), ctx.biomeSource(), ctx.randomState(), ctx.heightAccessor(),
                ctx.seed(), ctx.validBiome(), STATES.get(ctx.biomeSource()));
        return get(env);
    }

    /** Per il comando /viltrumites hq. @return il chunk di partenza della base nella dimensione del livello, o null */
    public static ChunkPos locate(ServerLevel level) {
        Structure structure = level.registryAccess().registryOrThrow(Registries.STRUCTURE).get(OUR_SET);
        if (structure == null) {
            return null;
        }
        ServerChunkCache cache = level.getChunkSource();
        ChunkGenerator gen = cache.getGenerator();
        Env env = new Env(gen, gen.getBiomeSource(), cache.randomState(), level, level.getSeed(),
                structure.biomes()::contains, cache.getGeneratorState());
        return get(env);
    }

    private static ChunkPos get(Env env) {
        synchronized (CACHE) {
            Result cached = CACHE.get(env.biomes());
            if (cached != null && cached.seed() == env.seed()) {
                return cached.pos();
            }
            ChunkPos found = search(env);
            CACHE.put(env.biomes(), new Result(env.seed(), found));
            return found;
        }
    }

    // ---- scelta della casella -------------------------------------------------------------------------------

    private static ChunkPos search(Env env) {
        List<Cand> near = candidates(env, GuardiansHq.MIN_DISTANCE, GuardiansHq.NEAR_MAX_DISTANCE);
        Cand best = pick(near);
        if (best == null || best.tier() > 3) {
            // niente di buono vicino: si allarga la ricerca
            List<Cand> all = new ArrayList<>(near);
            all.addAll(candidates(env, GuardiansHq.NEAR_MAX_DISTANCE, GuardiansHq.FAR_MAX_DISTANCE));
            Cand wider = pick(all);
            if (wider != null) {
                best = wider;
            }
        }
        return best == null ? null : best.pos();
    }

    /** La migliore: tier piu' basso (libera + montagna), a parita' un ordine casuale ma fisso per il seed. */
    private static Cand pick(List<Cand> list) {
        Cand best = null;
        for (Cand c : list) {
            if (best == null || c.tier() < best.tier() || (c.tier() == best.tier() && c.rank() < best.rank())) {
                best = c;
            }
        }
        return best;
    }

    private static List<Cand> candidates(Env env, int minDistance, int maxDistance) {
        List<Cand> out = new ArrayList<>();
        int reach = maxDistance / (GuardiansHq.SPACING * 16) + 2;
        for (int rx = -reach; rx <= reach; rx++) {
            for (int rz = -reach; rz <= reach; rz++) {
                ChunkPos c = GRID.getPotentialStructureChunk(env.seed(), rx, rz);
                double dist = Math.hypot(c.getMiddleBlockX(), c.getMiddleBlockZ());
                if (dist < minDistance || dist >= maxDistance) {
                    continue;
                }
                Cand cand = evaluate(env, c, rx, rz);
                if (cand != null) {
                    out.add(cand);
                }
            }
        }
        return out;
    }

    private static Cand evaluate(Env env, ChunkPos c, int rx, int rz) {
        int x = c.getMiddleBlockX();
        int z = c.getMiddleBlockZ();
        int ground = env.gen().getBaseHeight(x, z, Heightmap.Types.OCEAN_FLOOR_WG, env.ha(), env.rs());
        int surface = env.gen().getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, env.ha(), env.rs());
        if (surface > ground) {
            return null; // acqua
        }
        // abbastanza in alto da nascondere la base (con un po' di margine per i dislivelli sotto l'impronta)
        if (ground - GuardiansHq.SIZE_Y - GuardiansHq.COVER - 16 < env.ha().getMinBuildHeight() + 6) {
            return null;
        }
        Holder<Biome> biome = env.biomes().getNoiseBiome(
                QuartPos.fromBlock(x), QuartPos.fromBlock(ground), QuartPos.fromBlock(z), env.rs().sampler());
        if (!env.valid().test(biome)) {
            return null;
        }
        boolean mountain = biome.is(MOUNTAINS);
        int clear = clearRange(env, c, biome);
        // 0 = libera + montagna ... 5 = occupata + altro bioma
        int tier = (clear >= GuardiansHq.CLEAR_RANGE ? 0 : clear >= GuardiansHq.CLEAR_RANGE_RELAXED ? 1 : 2) * 2
                + (mountain ? 0 : 1);
        long rank = new Random(env.seed() ^ (rx * 341873128712L) ^ (rz * 132897987541L) ^ GuardiansHq.SALT).nextLong();
        return new Cand(c, mountain, tier, rank);
    }

    /**
     * Il raggio piu' grande (CLEAR_RANGE, CLEAR_RANGE_RELAXED o 0) attorno al chunk senza punti di partenza di altre
     * strutture. Si considerano solo i gruppi di strutture che potrebbero nascere nel bioma di questo punto.
     */
    private static int clearRange(Env env, ChunkPos c, Holder<Biome> biome) {
        ChunkGeneratorStructureState state = env.state();
        if (state == null) {
            return GuardiansHq.CLEAR_RANGE; // stato non disponibile: nessun controllo possibile
        }
        List<Holder<StructureSet>> relevant = new ArrayList<>();
        for (Holder<StructureSet> set : state.possibleStructureSets()) {
            if (set.is(OUR_SET)) {
                continue;
            }
            for (StructureSet.StructureSelectionEntry entry : set.value().structures()) {
                if (entry.structure().value().biomes().contains(biome)) {
                    relevant.add(set);
                    break;
                }
            }
        }
        if (!anyNear(state, relevant, c, GuardiansHq.CLEAR_RANGE)) {
            return GuardiansHq.CLEAR_RANGE;
        }
        if (!anyNear(state, relevant, c, GuardiansHq.CLEAR_RANGE_RELAXED)) {
            return GuardiansHq.CLEAR_RANGE_RELAXED;
        }
        return 0;
    }

    private static boolean anyNear(ChunkGeneratorStructureState state, List<Holder<StructureSet>> sets,
                                   ChunkPos c, int range) {
        for (Holder<StructureSet> set : sets) {
            if (state.hasStructureChunkInRange(set, c.x, c.z, range)) {
                return true;
            }
        }
        return false;
    }
}
