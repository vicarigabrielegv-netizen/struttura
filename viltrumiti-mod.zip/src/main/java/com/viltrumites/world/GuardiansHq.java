package com.viltrumites.world;

/**
 * Misure della base dei Guardiani del Globo (template {@code structures/guardians_hq.nbt}, 81 x 49 x 73).
 *
 * La base e' un grande tamburo circolare (diametro 73, centro locale x=36, z=36) con un breve
 * corridoio sul lato +X (locale): l'ultimo blocco d'aria del corridoio e' a x=80, cioe' a 44 blocchi dal centro,
 * largo 7 (z 33..39) e alto 4 (y 9..12), con il pavimento a y=8. Da li' parte la rampa generata dal codice
 * ({@link GuardiansTunnelPiece}) che porta alla superficie della montagna.
 */
public final class GuardiansHq {
    private GuardiansHq() {}

    /** Altezza del template. */
    public static final int SIZE_Y = 49;
    /** Centro del tamburo (coordinate locali x e z): e' anche il perno della rotazione. */
    public static final int CENTER = 36;
    /** Raggio del tamburo (blocchi). */
    public static final int RADIUS = 36;
    /** Distanza dal centro dell'ultimo blocco d'aria del corridoio d'ingresso. */
    public static final int MOUTH_OFFSET = 44;
    /** Quota locale del pavimento del corridoio (si cammina a FLOOR_Y + 1). */
    public static final int FLOOR_Y = 8;
    /** Metà della larghezza della rampa: 3 blocchi per lato = 7 liberi, piu' le pareti a +-4. */
    public static final int HALF_WIDTH = 4;
    /** Blocchi di roccia che devono restare sopra il tetto della base nel punto piu' basso del terreno. */
    public static final int COVER = 8;
    /**
     * Lunghezza massima della rampa (un gradino per blocco). Con il corridoio (44) arriva a 132 blocchi dal centro:
     * oltre gli 8 chunk dal punto di partenza il gioco non genera piu' i pezzi di una struttura.
     */
    public static final int MAX_STEPS = 88;

    // Posizionamento: griglia "random_spread" (stessi valori di worldgen/structure_set/guardians_hq.json).
    // GuardiansHqSite sceglie in modo deterministico UNA sola casella della griglia.
    public static final int SPACING = 64;
    public static final int SEPARATION = 16;
    public static final int SALT = 1951703;

    /** Distanza minima dall'origine del mondo (blocchi): la base non deve essere facile da trovare. */
    public static final int MIN_DISTANCE = 2500;
    /** Prima si cerca fino a questa distanza... */
    public static final int NEAR_MAX_DISTANCE = 6000;
    /** ...e solo se non c'e' niente di adatto si allarga fino a questa. */
    public static final int FAR_MAX_DISTANCE = 10000;

    /** Raggio (in chunk) attorno alla base che deve essere libero da punti di partenza di altre strutture. */
    public static final int CLEAR_RANGE = 8;
    /** Raggio ridotto usato solo se con quello normale non si trova nessun posto. */
    public static final int CLEAR_RANGE_RELAXED = 4;
}
