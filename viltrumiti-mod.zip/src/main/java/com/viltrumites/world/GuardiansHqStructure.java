package com.viltrumites.world;

import com.mojang.serialization.Codec;
import com.viltrumites.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

import java.util.Optional;

/**
 * Base dei Guardiani del Globo: una struttura unica per mondo. Il JSON del structure_set offre le caselle di una griglia
 * "random_spread"; {@link GuardiansHqSite} sceglie quella giusta (montagne per prime) e tutte le altre vengono scartate.
 *
 * Qui si decide COME mettere la base nel punto scelto:
 *  - la base viene sepolta sotto la roccia: il tetto sta {@link GuardiansHq#COVER} blocchi sotto la superficie
 *    nel punto piu' basso del terreno sopra la sua impronta;
 *  - si prova ognuna delle 4 rotazioni e si sceglie quella dove l'ingresso raggiunge la superficie con la rampa
 *    piu' corta (cioe' il lato dove la montagna scende), evitando se possibile uscite sott'acqua;
 *  - la rampa vera e propria la scava {@link GuardiansTunnelPiece}.
 * Tutto si basa sull'altezza del terreno del generatore in uso, quindi funziona con qualunque mondo
 * (vanilla, mondi alterati da mod, dimensioni personalizzate con altre quote minime e massime).
 */
public class GuardiansHqStructure extends Structure {
    public static final Codec<GuardiansHqStructure> CODEC = simpleCodec(GuardiansHqStructure::new);

    /** Penalita' (in gradini) per un'uscita in acqua: si sceglie un altro lato se possibile. */
    private static final int WET_PENALTY = 80;

    public GuardiansHqStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.GUARDIANS_HQ.get();
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext ctx) {
        ChunkPos cp = ctx.chunkPos();
        ChunkPos site = GuardiansHqSite.get(ctx);
        if (site == null || !site.equals(cp)) {
            return Optional.empty(); // non e' la casella scelta per la base di questo mondo
        }

        ChunkGenerator gen = ctx.chunkGenerator();
        LevelHeightAccessor ha = ctx.heightAccessor();
        RandomState rs = ctx.randomState();
        int cx = cp.getMiddleBlockX();
        int cz = cp.getMiddleBlockZ();

        // 1) punto piu' basso della superficie sotto l'impronta circolare della base
        int r = GuardiansHq.RADIUS;
        int minH = Integer.MAX_VALUE;
        for (int dx = -r; dx <= r; dx += 6) {
            for (int dz = -r; dz <= r; dz += 6) {
                if (dx * dx + dz * dz <= r * r) {
                    minH = Math.min(minH, height(gen, ha, rs, cx + dx, cz + dz));
                }
            }
        }

        // 2) quota del fondo: il tetto resta COVER blocchi sotto il punto piu' basso.
        //    Se nessun lato arriva in superficie entro la lunghezza massima della rampa si prova piu' in alto.
        int deepest = minH - GuardiansHq.SIZE_Y - GuardiansHq.COVER;
        Rotation[] rotations = Rotation.values();
        int start = ctx.random().nextInt(rotations.length);
        Rotation bestRot = null;
        int bestSteps = 0;
        int baseY = 0;
        for (int lift = 0; lift <= 24 && bestRot == null; lift += 8) {
            baseY = deepest + lift;
            if (baseY < ha.getMinBuildHeight() + 6 || baseY + GuardiansHq.SIZE_Y >= ha.getMaxBuildHeight()) {
                continue; // fuori dai limiti del mondo
            }
            // 3) rotazione: ingresso con la rampa piu' corta fino alla superficie (a parita', a caso)
            int bestScore = Integer.MAX_VALUE;
            for (int k = 0; k < rotations.length; k++) {
                Rotation rot = rotations[(start + k) % rotations.length];
                Direction dir = rot.rotate(Direction.EAST); // il corridoio del template guarda verso +X
                int[] scan = scanRamp(gen, ha, rs, cx, cz, baseY, dir);
                if (scan == null) {
                    continue;
                }
                int score = scan[0] + (scan[1] != 0 ? WET_PENALTY : 0);
                if (score < bestScore) {
                    bestScore = score;
                    bestRot = rot;
                    bestSteps = scan[0];
                }
            }
        }
        if (bestRot == null) {
            return Optional.empty(); // nessun lato raggiunge la superficie
        }

        // 4) pezzi: il template (angolo 0,0,0 = centro - perno) e la rampa
        final Rotation rotation = bestRot;
        final int steps = bestSteps;
        final int floorY = baseY;
        final Direction dir = rotation.rotate(Direction.EAST);
        BlockPos templatePos = new BlockPos(cx - GuardiansHq.CENTER, floorY, cz - GuardiansHq.CENTER);
        // la posizione di riferimento e' in superficie, cosi' il controllo del bioma usa il bioma di superficie
        BlockPos stubPos = new BlockPos(cx, height(gen, ha, rs, cx, cz), cz);
        return Optional.of(new Structure.GenerationStub(stubPos, builder -> {
            builder.addPiece(new GuardiansHqPiece(ctx.structureTemplateManager(), templatePos, rotation));
            if (steps > 0) {
                builder.addPiece(new GuardiansTunnelPiece(cx, cz, floorY, dir, steps));
            }
        }));
    }

    /**
     * Quanti gradini servono dalla bocca del corridoio fino alla superficie in direzione dir.
     * @return {gradini, 1 se l'uscita e' in acqua} oppure null se la superficie non si raggiunge
     */
    private static int[] scanRamp(ChunkGenerator gen, LevelHeightAccessor ha, RandomState rs,
                                  int cx, int cz, int baseY, Direction dir) {
        for (int i = 1; i <= GuardiansHq.MAX_STEPS; i++) {
            int x = cx + dir.getStepX() * (GuardiansHq.MOUTH_OFFSET + i);
            int z = cz + dir.getStepZ() * (GuardiansHq.MOUTH_OFFSET + i);
            int h = height(gen, ha, rs, x, z);
            int stairY = baseY + GuardiansHq.FLOOR_Y + i;
            if (stairY >= h) {
                // il gradino i sarebbe fuori dal terreno: l'ultimo e' il precedente
                int top = gen.getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, ha, rs);
                return new int[] {i - 1, top > h ? 1 : 0};
            }
        }
        return null;
    }

    /** Quota del primo blocco libero sopra al terreno solido (l'acqua non conta come terreno). */
    private static int height(ChunkGenerator gen, LevelHeightAccessor ha, RandomState rs, int x, int z) {
        return gen.getBaseHeight(x, z, Heightmap.Types.OCEAN_FLOOR_WG, ha, rs);
    }
}
