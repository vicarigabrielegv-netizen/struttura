package com.viltrumites.world;

import com.viltrumites.registry.ModStructures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/**
 * Rampa d'ingresso: parte dal corridoio della base e sale di un blocco ogni blocco, scavando la montagna,
 * fino a uscire in superficie. Sezione: 7 blocchi liberi (+ pareti), alta 5 sopra ai gradini, con rivestimento
 * in mattoni di ardesia profonda e qualche lanterna marina. Pareti e soffitto sono sempre completi sotto la
 * superficie (anche dove la rampa taglia una grotta) e vengono messi solo dove c'e' roccia in aria aperta.
 */
public class GuardiansTunnelPiece extends StructurePiece {
    private final int cx;
    private final int cz;
    private final int baseY;
    private final Direction dir;
    private final int steps;

    public GuardiansTunnelPiece(int cx, int cz, int baseY, Direction dir, int steps) {
        super(ModStructures.GUARDIANS_TUNNEL_PIECE.get(), 0, makeBox(cx, cz, baseY, dir, steps));
        this.cx = cx;
        this.cz = cz;
        this.baseY = baseY;
        this.dir = dir;
        this.steps = steps;
    }

    public GuardiansTunnelPiece(CompoundTag tag) {
        super(ModStructures.GUARDIANS_TUNNEL_PIECE.get(), tag);
        this.cx = tag.getInt("CX");
        this.cz = tag.getInt("CZ");
        this.baseY = tag.getInt("BaseY");
        this.dir = Direction.from3DDataValue(tag.getInt("Dir"));
        this.steps = tag.getInt("Steps");
    }

    private static BoundingBox makeBox(int cx, int cz, int baseY, Direction dir, int steps) {
        Direction side = dir.getClockWise();
        int ax = cx + dir.getStepX() * (GuardiansHq.MOUTH_OFFSET + 1);
        int az = cz + dir.getStepZ() * (GuardiansHq.MOUTH_OFFSET + 1);
        int bx = cx + dir.getStepX() * (GuardiansHq.MOUTH_OFFSET + steps);
        int bz = cz + dir.getStepZ() * (GuardiansHq.MOUTH_OFFSET + steps);
        int sx = side.getStepX() * GuardiansHq.HALF_WIDTH;
        int sz = side.getStepZ() * GuardiansHq.HALF_WIDTH;
        int minX = Math.min(Math.min(ax - sx, ax + sx), Math.min(bx - sx, bx + sx));
        int maxX = Math.max(Math.max(ax - sx, ax + sx), Math.max(bx - sx, bx + sx));
        int minZ = Math.min(Math.min(az - sz, az + sz), Math.min(bz - sz, bz + sz));
        int maxZ = Math.max(Math.max(az - sz, az + sz), Math.max(bz - sz, bz + sz));
        return new BoundingBox(minX, baseY + GuardiansHq.FLOOR_Y, minZ,
                maxX, baseY + GuardiansHq.FLOOR_Y + steps + 6, maxZ);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("CX", this.cx);
        tag.putInt("CZ", this.cz);
        tag.putInt("BaseY", this.baseY);
        tag.putInt("Dir", this.dir.get3DDataValue());
        tag.putInt("Steps", this.steps);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager structureManager, ChunkGenerator generator,
                            RandomSource random, BoundingBox box, ChunkPos chunkPos, BlockPos pos) {
        Direction side = this.dir.getClockWise();
        BlockState bricks = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState lantern = Blocks.SEA_LANTERN.defaultBlockState();
        BlockState stair = Blocks.DEEPSLATE_BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, this.dir);
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

        for (int i = 1; i <= this.steps; i++) {
            int ax = this.cx + this.dir.getStepX() * (GuardiansHq.MOUTH_OFFSET + i);
            int az = this.cz + this.dir.getStepZ() * (GuardiansHq.MOUTH_OFFSET + i);
            int y = this.baseY + GuardiansHq.FLOOR_Y + i; // quota del gradino i
            for (int w = -GuardiansHq.HALF_WIDTH; w <= GuardiansHq.HALF_WIDTH; w++) {
                int x = ax + side.getStepX() * w;
                int z = az + side.getStepZ() * w;
                if (x < box.minX() || x > box.maxX() || z < box.minZ() || z > box.maxZ()) {
                    continue;
                }
                boolean wall = Math.abs(w) == GuardiansHq.HALF_WIDTH;
                // primo blocco libero sopra il terreno: sotto (con 1 blocco di roccia sopra) il rivestimento e' sempre
                // completo, anche dove la rampa taglia una grotta, cosi' non restano buchi
                int ground = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z);
                for (int h = -1; h <= 6; h++) {
                    int yy = y + h;
                    if (yy < box.minY() || yy > box.maxY()) {
                        continue;
                    }
                    p.set(x, yy, z);
                    BlockState cur = level.getBlockState(p);
                    if (wall) {
                        // pareti: dove c'e' roccia, e sempre se sotto la superficie
                        if (!cur.isAir() || yy < ground - 1) {
                            level.setBlock(p, (h == 3 && i % 6 == 0) ? lantern : bricks, 2);
                        }
                    } else if (h == -1) {
                        // sotto al gradino: riempie vuoti e liquidi
                        if (cur.isAir() || !cur.getFluidState().isEmpty()) {
                            level.setBlock(p, bricks, 2);
                        }
                    } else if (h == 0) {
                        level.setBlock(p, stair, 2);
                    } else if (h == 6) {
                        if (!cur.isAir() || yy < ground - 1) {
                            level.setBlock(p, bricks, 2);
                        }
                    } else if (!cur.isAir()) {
                        level.setBlock(p, air, 2); // volume libero, alto 5 sopra al gradino
                    }
                }
            }
        }
    }
}
